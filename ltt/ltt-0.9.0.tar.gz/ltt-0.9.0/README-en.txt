http://ice.dammit.lt/~mgedmin/ltt/index-en.html
-------------------------------------------------------------------------------

                              Lithuanian Text Tool

What is it?

   In the old dark times many different encodings were used for Lithuanian
   texts. LTT (Lithuanian Text Tool) is a small program that does two things:

     * it tries to guess which encoding was used for the text

+--------------------------------------------------------------------------------+
|$ ltt index.in                                                                  |
|index.in                                                                        |
|Probability   Charset                                      Seen characters      |
|    57%  *!   Latin-7/ISO-8859-13/Baltic-RIM/ANSI-1257     .........`ae.ead-�uth|
|    38%       771/773/KBL                                  ..d-...�.........u.  |
|     4%       Latin-4/ISO-8859-4/Latin-6/ISO-8859-10       ..........e.....th.  |
|  * -- file contains Lithuanian letters unique to this charset                  |
|  ! -- file contains no Lithuanian letters outside of this charset              |
+--------------------------------------------------------------------------------+

     * it can recode Lithuanian letters from one encoding to another

+-----------------------------------------------------------------------------------+
|$ ltt -c latin-7 latin-4 index.in                                                  |
|Latin-7/ISO-8859-13/Baltic-RIM/ANSI-1257 -> Latin-4/ISO-8859-4/Latin-6/ISO-8859-10:|
|index.in                                                                           |
|                                                                                   |
|$ ltt index.in                                                                     |
|index.in                                                                           |
|Probability   Charset                                      Seen characters         |
|    66%  *!   Latin-4/ISO-8859-4/Latin-6/ISO-8859-10       .........�e.`ic,�uth�   |
|    16%       771/773/KBL                                  ...............u..      |
|    11%       Latin-7/ISO-8859-13/Baltic-RIM/ANSI-1257     ..........e......th     |
|     5%       772/774/775                                  .....�............      |
|  * -- file contains Lithuanian letters unique to this charset                     |
|  ! -- file contains no Lithuanian letters outside of this charset                 |
+-----------------------------------------------------------------------------------+

Notes:

     * Only Lithuanian national letters are recoded
     * The following encodings are supported:
          * 772, 774, 775
          * 770 (also known as IBM Baltic)
          * 771, 773 (also known as KBL)
          * ISO-8859-13 (also known as Latin-7), Windows-1257 (also known as
            Baltic RIM)
          * ISO-8859-4 (also known as Latin-4), ISO-8859-10 (also known as
            Latin-6)
       Encodings that share the same Lithuanian letter positions are listed
       on one line.
     * It is also possible to convert text to plain ASCII (but,
       unfortunatelly, not back)
     * User interface is in English (that might seem strange considering its
       purpose and target audience)
     * Ltt is written in Pascal. It can be compiled for DOS, Windows Linux by
       using Turbo Pascal, Borland Delphi and Free Pascal.
     * Ltt is Free Software licenced under the GNU GPL.

Usage

     +-----------------------------------------------------------------------+
     |$ ltt                                                                  |
     |Lithuanian Text Tool version 0.9.0                                     |
     |Copyright (c) 1999-2001 Marius Gedminas <mgedmin@delfi.lt>             |
     |This is Free Software.  See the GNU General Public Licence for details.|
     |                                                                       |
     |Try to autodetect charset:                                             |
     |  ltt [-q] <filename>                                                  |
     |                                                                       |
     |      -q        quick mode: only check first kilobyte                  |
     |                                                                       |
     |Convert between charsets:                                              |
     |  ltt -c <charset1> <charset2> [-b <ext>] <filename> ...               |
     |                                                                       |
     |      -b <ext>  create backup files with extension <ext>               |
     |                (<ext> should begin with a dot, e.g. -b .bak)          |
     |                                                                       |
     |Use `-' instead of <filename> for standard input                       |
     |                                                                       |
     |Possible charset values:                                               |
     |  772 774 775                                                          |
     |  770                                                                  |
     |  771 773 kbl                                                          |
     |  lat7 latin-7 iso-8859-13 brim baltic-rim 1257                        |
     |  lat4 latin-4 iso-8859-4 lat6 latin-6 iso-8859-10                     |
     |You can also use `ascii' for <charset2>                                |
     |                                                                       |
     |Note: only 18 Lithuanian national letters are affected.                |
     +-----------------------------------------------------------------------+

Download

   LTT version 0.9.0

     * ltt.pas (16K) -- source code
     * COPYING (18K) -- licence (GNU GPL v2)
     * ltt-0.9.0.zip (51K) -- ZIP archive containing source code and
       precompiled Windows and DOS executables.
     * ltt-0.9.0.tar.gz (46K) -- TAR.GZ archive containing source code and
       precompiled Linux executable.

   Linux

     * ltt (79K) -- static ELF executable for i386

   Windows

     * ltt32.exe (51K) -- Win32 executable

   DOS

     * ltt16.exe (13K) -- DOS executable

-------------------------------------------------------------------------------
Copyright � 2001 Marius Gedminas                   $Date: 2001/04/19 00:54:24 $

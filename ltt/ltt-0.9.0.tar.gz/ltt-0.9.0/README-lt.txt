http://ice.dammit.lt/~mgedmin/ltt/index-lt.html
-------------------------------------------------------------------------------

                         Lietuvi�ko teksto perkodavimas

Kas tai?

   Senais tamsiais laikais buvo vartojama daug skirting� kodavimo lenteli�
   lietuvi�kiems tekstams saugoti. LTT (Lithuanian Text Tool) yra program�l�,
   atliekanti dvi funkcijas:

     * ji bando nustatyti, kokia lentele yra u�koduotas tekstas

 +-----------------------------------------------------------------------------+
 |$ ltt index.in                                                               |
 |index.in                                                                     |
 |Probability   Charset                                      Seen characters   |
 |    57%  *!   Latin-7/ISO-8859-13/Baltic-RIM/ANSI-1257     .........��.������|
 |    38%       771/773/KBL                                  ..�...�.........�.|
 |     4%       Latin-4/ISO-8859-4/Latin-6/ISO-8859-10       ..........�.....�.|
 |  * -- file contains Lithuanian letters unique to this charset               |
 |  ! -- file contains no Lithuanian letters outside of this charset           |
 +-----------------------------------------------------------------------------+

     * ji gali perkoduoti lietuvi�kas raides i� vienos lentel�s � kit�

+-----------------------------------------------------------------------------------+
|$ ltt -c latin-7 latin-4 index.in                                                  |
|Latin-7/ISO-8859-13/Baltic-RIM/ANSI-1257 -> Latin-4/ISO-8859-4/Latin-6/ISO-8859-10:|
|index.in                                                                           |
|                                                                                   |
|$ ltt index.in                                                                     |
|index.in                                                                           |
|Probability   Charset                                      Seen characters         |
|    66%  *!   Latin-4/ISO-8859-4/Latin-6/ISO-8859-10       .........��.�����      |
|    16%       771/773/KBL                                  ...............�..      |
|    11%       Latin-7/ISO-8859-13/Baltic-RIM/ANSI-1257     ..........�......�      |
|     5%       772/774/775                                  .....�............      |
|  * -- file contains Lithuanian letters unique to this charset                     |
|  ! -- file contains no Lithuanian letters outside of this charset                 |
+-----------------------------------------------------------------------------------+

�vairios pastabos:

     * Perkoduojant kei�iamos tik lietuvi�kos raid�s
     * Palaikomos �ios kod� lentel�s:
          * 772, 774, 775
          * 770 (dar vadinama IBM Baltic)
          * 771, 773 (dar vadinama KBL)
          * ISO-8859-13 (dar vadinama Latin-7), Windows-1257 (dar vadinama
            Baltic RIM)
          * ISO-8859-4 (dar vadinama Latin-4), ISO-8859-10 (dar vadinama
            Latin-6)
       Vienoje eilut�je sura�ytos lentel�s, kuriose lietuvi�k� raid�i� kodai
       yra tie patys.
     * Taip pat yra galimyb� perkoduoti � ��vepl� tekst� (deja, perkoduoti
       atgal nebepavyks...)
     * Programa su vartotoju bendrauja angli�kai (a� keistas �mogus)
     * Program�l� para�yta Paskaliu. J� galima sukompiliuoti DOS, Windows bei
       Linux terp�se naudojant Turbo Pascal, Borland Delphi arba Free Pascal.
     * Programa yra laisva ir nemokama, jos licencija -- GNU GPL.

Instrukcija

     +-----------------------------------------------------------------------+
     |$ ltt                                                                  |
     |Lithuanian Text Tool version 0.9.0                                     |
     |Copyright (c) 1999-2001 Marius Gedminas <mgedmin@delfi.lt>             |
     |This is Free Software.  See the GNU General Public Licence for details.|
     |                                                                       |
     |Try to autodetect charset:                                             |
     |  ltt [-q] <filename>                                                  |
     |                                                                       |
     |      -q        quick mode: only check first kilobyte                  |
     |                                                                       |
     |Convert between charsets:                                              |
     |  ltt -c <charset1> <charset2> [-b <ext>] <filename> ...               |
     |                                                                       |
     |      -b <ext>  create backup files with extension <ext>               |
     |                (<ext> should begin with a dot, e.g. -b .bak)          |
     |                                                                       |
     |Use `-' instead of <filename> for standard input                       |
     |                                                                       |
     |Possible charset values:                                               |
     |  772 774 775                                                          |
     |  770                                                                  |
     |  771 773 kbl                                                          |
     |  lat7 latin-7 iso-8859-13 brim baltic-rim 1257                        |
     |  lat4 latin-4 iso-8859-4 lat6 latin-6 iso-8859-10                     |
     |You can also use `ascii' for <charset2>                                |
     |                                                                       |
     |Note: only 18 Lithuanian national letters are affected.                |
     +-----------------------------------------------------------------------+

Parsisiuntimas

   LTT versija 0.9.0

     * ltt.pas (16K) -- pradinis kodas
     * COPYING (18K) -- licencija (GNU GPL v2)
     * ltt-0.9.0.zip (51K) -- ZIP archyvas su pradiniu kodu bei
       sukompiliuotomis Windows ir DOS versijomis.
     * ltt-0.9.0.tar.gz (46K) -- TAR.GZ archyvas su pradiniu kodu bei
       sukompiliuota Linux versija.

   Linux

     * ltt (79K) -- statin� ELF programa i386 architekt�rai

   Windows

     * ltt32.exe (51K) -- Win32 programa

   DOS

     * ltt16.exe (13K) -- DOS programa

-------------------------------------------------------------------------------
Copyright � 2001 Marius Gedminas                   $Date: 2001/04/19 00:54:24 $

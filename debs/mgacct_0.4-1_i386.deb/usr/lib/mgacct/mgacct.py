"""mgacct common routines"""

#
# Config file
#

class Config:

    # Pathnames
    rrdDir = "/var/lib/mgacct"
    imgDir = "/var/www/mgacct"

    # Misc
    verbose = 0
    autoGraph = 1
    lazy = 0
    hostname = ""
    groupbits = 7   # 128 items per group
    showbits = 0    # show bits, not bytes

    # RRD archives
    timespecs = (('day',   '-x HOUR:1:HOUR:24:HOUR:1:0:%H'),
                 ('week',  '-s end-1week'),
                 ('month', '-s end-1month'),
                 ('year',  '-s end-1year -x MONTH:1:MONTH:12:MONTH:1:2592000:%b'))
    schema = """\
DS:in:DERIVE:600:0:U
DS:out:DERIVE:600:0:U
DS:inproxy:DERIVE:600:0:U
DS:outproxy:DERIVE:600:0:U
"""
    archives = """\
RRA:AVERAGE:0.5:1:600
RRA:AVERAGE:0.5:6:700
RRA:AVERAGE:0.5:24:775
RRA:AVERAGE:0.5:288:797
"""
    graphTemplate = """\
--title '$(CLIENT)'
--lower-limit 0
--alt-autoscale-max
$(BITSORBYTES)
CDEF:intotal=in,inp,+
CDEF:outtotal=out,outp,+
'AREA:intotal#00FF00:Incoming'
'AREA:inp#00A000:(proxied)'
'LINE1:outtotal#0000FF:Outgoing'
'LINE1:outp#0000A0:(proxied)\l'
'GPRINT:intotal:AVERAGE:in avg=%.0lf%s'
'GPRINT:intotal:MAX:max=%.0lf%s'
'GPRINT:intotal:LAST:cur=%.0lf%s'
'GPRINT:outtotal:AVERAGE:out avg=%.0lf%s'
'GPRINT:outtotal:MAX:max=%.0lf%s'
'GPRINT:outtotal:LAST:cur=%.0lf%s\\r'
"""
    graphInBits = """\
--vertical-label 'bits/sec'
DEF:inbytes=$(FILENAME):in:AVERAGE
DEF:outbytes=$(FILENAME):out:AVERAGE
DEF:inpbytes=$(FILENAME):inproxy:AVERAGE
DEF:outpbytes=$(FILENAME):outproxy:AVERAGE
'CDEF:in=inbytes,8,*'
'CDEF:out=outbytes,8,*'
'CDEF:inp=inpbytes,8,*'
'CDEF:outp=outpbytes,8,*'
"""
    graphInBytes = """\
--vertical-label 'bytes/sec'
DEF:in=$(FILENAME):in:AVERAGE
DEF:out=$(FILENAME):out:AVERAGE
DEF:inp=$(FILENAME):inproxy:AVERAGE
DEF:outp=$(FILENAME):outproxy:AVERAGE
"""


class ConfigError(Exception):
    """mgacct config file error"""
    pass

def parseConfig(filename="/etc/mgacct.conf"):
    """Parses mgacct config file and returns a Config object."""

    cfg = Config()
    cf = open(filename)
    cfg.clients = []
    section = 'clients'
    for line in cf.readlines():
        idx = line.find('#')
        if idx >= 0: line = line[:idx]
        line = line.strip()
        if not line: continue
        if line[0] == '[':
            if line[-1] != ']':
                raise ConfigError, 'Bad section name: %s' % line
            section = line[1:-1].strip().lower()
            continue
        if section == 'clients':
            if '-' in line:
                first, last = line.split('-')
                first = parse_ip(first.strip())
                last = parse_ip(last.strip())
                for ip in range(first, last+1):
                    cfg.clients.append(ip)
            else:
                ip = parse_ip(line)
                cfg.clients.append(ip)
        elif section == 'paths':
            key, value = line.split('=')
            key = key.strip().lower()
            value = value.strip()
            if key == "rrddir": cfg.rrdDir = value
            elif key == "imgdir": cfg.imgDir = value
        elif section == 'misc':
            key, value = line.split('=')
            key = key.strip().lower()
            value = value.strip()
            if key == "verbose": cfg.verbose = int(value)
            elif key == "autograph": cfg.autoGraph = int(value)
            elif key == "lazy": cfg.lazy = int(value)
            elif key == "hostname": cfg.hostname = value
            elif key == "groupbits": cfg.groupbits = int(value)
            elif key == "showbits": cfg.showbits = int(value)
        # XXX: perform some validation and show nice errors, not exceptions
    return cfg

#
# Misc utils
#

def parse_ip(ip):
    """Parse a dotted-decimal style IP address."""
    a, b, c, d = map(int, ip.split("."))
    return (a << 24) + (b << 16) + (c << 8) + d

def format_ip(ip):
    """Format a dotted-decimal style IP address for output."""
    return "%d.%d.%d.%d" % ((ip >> 24) & 0xFF, (ip >> 16) & 0xFF,
                            (ip >> 8) & 0xFF, ip & 0xFF)

def escapeFS(fn):
    """Escape file-system unsafe characters for file names."""
    return fn.replace("%", '%25').replace("/", '%2f')

def escapeHtml(fn):
    """Escape file names for inclusion into HTML."""
    return fn.replace('&', '&amp;')\
             .replace('"', '&quot;')\
             .replace('<', '&lt')\
             .replace('>', '&rt')\
             .replace('%', '%25')


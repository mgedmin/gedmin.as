#!/bin/sh

# Config
iptables=/sbin/iptables

# Determine external interface
ext_if=`/sbin/route -n|grep '^0\.0\.0\.0'|awk '{print $8}'`
if [ -z "$ext_if" ]; then
    echo "$0: could not determine interface of the default route"
    exit 1
fi

# Detach and delete old iptables chains
$iptables -D FORWARD -o $ext_if -j acct				2>/dev/null
$iptables -D FORWARD -i $ext_if -j acct				2>/dev/null
$iptables -D INPUT -p tcp --dport 3128 -j acct-proxy		2>/dev/null
$iptables -D OUTPUT -p tcp --sport 3128 -j acct-proxy		2>/dev/null
$iptables -F acct						2>/dev/null
$iptables -F acct-proxy						2>/dev/null
$iptables -X acct						2>/dev/null
$iptables -X acct-proxy						2>/dev/null

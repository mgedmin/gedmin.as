#!/usr/bin/python2.2
import os
import os.path
import sys
import traceback

import mgacct

# Hardcoded paths
configFile = "/etc/mgacct.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgacct.parseConfig(configFile)

if not config.clients:
    # nothing to do
    sys.exit(0)

for client in config.clients:
    try:
        client_ip = mgacct.format_ip(client)
        rrdFile = os.path.join(config.rrdDir, client_ip + ".rrd")
        if not os.path.exists(rrdFile):
            print >> sys.stderr, "%s does not exist, skipping" % rrdFile
            continue
        for time, timespec in config.timespecs:
            imgFile = os.path.join(config.imgDir, client_ip)
            imgFile += "-%s.png" % time
            vars = {}
            vars['FILENAME'] = rrdFile
            vars['CLIENT'] = client_ip
            vars['INTERVAL'] = time
            rrdGraph = config.graphTemplate
            if config.showbits:
                rrdGraph = rrdGraph.replace("$(BITSORBYTES)", config.graphInBits)
            else:
                rrdGraph = rrdGraph.replace("$(BITSORBYTES)", config.graphInBytes)
            for key, value in vars.items():
                rrdGraph = rrdGraph.replace("$(%s)" % key, value)
            if config.lazy: timespec += " -lazy"
            command = "rrdtool graph %s %s %s > /dev/null" % (timespec,
                                     imgFile, rrdGraph)
            command = command.replace("\n", " ")
            if config.verbose:
                print command
            os.system(command)
    except Exception, e:
        print >> sys.stderr, "%s:" % mgacct.format_ip(client)
        traceback.print_exc()
        continue

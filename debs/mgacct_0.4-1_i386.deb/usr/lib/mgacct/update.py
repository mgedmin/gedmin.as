#!/usr/bin/python2.2
import os
import os.path
import sys
import time
import traceback

import mgacct

# Hardcoded paths
configFile = "/etc/mgacct.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgacct.parseConfig(configFile)

if not config.clients:
    # nothing to do
    sys.exit(0)

# Parse iptables output

def parse_chain(name):
    acct_src, acct_dst = {}, {}
    iptables = os.popen("/sbin/iptables -vxnL %s 2>/dev/null" % name)
    iptables.readline() # skip header
    iptables.readline()
    alsocheck = {}
    for line in iptables.readlines():
        row = line.split()
        if row[2] != "all":
            alsocheck[row[2]] = 1
            continue
        source = row[6]
        dest = row[7]
        bytes = long(row[1])
        if source == '0.0.0.0/0':
            acct_dst[mgacct.parse_ip(dest)] = bytes
        else:
            acct_src[mgacct.parse_ip(source)] = bytes
    iptables.close()
    for also in alsocheck.keys():
        src, dst = parse_chain(also)
        acct_src.update(src)
        acct_dst.update(dst)
    return acct_src, acct_dst

acct_out, acct_in = parse_chain("acct")
now = int(time.time())
acct_out_p, acct_in_p = parse_chain("acct-proxy")

# Update the necessary RRDs
for client in config.clients:
    try:
        rrdFile = os.path.join(config.rrdDir, mgacct.format_ip(client) + ".rrd")
        if not os.path.exists(rrdFile):
            # need to create the rrd
            command = "rrdtool create %s %s %s" % (rrdFile, config.schema, config.archives)
            command = command.replace("\n", " ")
            if config.verbose:
                print command
            os.system(command)
        # update the rrd
        input = acct_in.get(client, "U")
        output = acct_out.get(client, "U")
        inproxy = acct_in_p.get(client, "U")
        outproxy = acct_out_p.get(client, "U")
        result = "%d:%s:%s:%s:%s" % (now, input, output,inproxy, outproxy)
        command = "rrdtool update %s %s" % (rrdFile, result)
        command = command.replace("\n", " ")
        if config.verbose:
            print command
        os.system(command)
    except Exception, e:
        print >> sys.stderr, "%s:" % mgacct.format_ip(client),
        traceback.print_exc()
        continue

if config.autoGraph:
    import autograph

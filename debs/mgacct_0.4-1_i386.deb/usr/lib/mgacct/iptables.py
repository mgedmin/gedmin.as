#!/usr/bin/python2.2
import os
import os.path
import sys
import time
import traceback

import mgacct

# Hardcoded paths
configFile = "/etc/mgacct.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgacct.parseConfig(configFile)

if not config.clients:
    # nothing to do
    sys.exit(0)

# Find out external interface
ext_if = os.popen("/sbin/route -n|grep '^0\.0\.0\.0'").read().split()[7]
if not ext_if:
    print >> sys.stderr, "could not determine intefrace of the default route"
    sys.exit(1)

# Group clients
groupmask = -1 << config.groupbits
groupsize = {}
for client in config.clients:
    group = client & groupmask
    groupsize.setdefault(group, 0)
    groupsize[group] += 1

# Generate iptables rules
command = """\
iptables -D FORWARD -o %(ext_if)s -j acct 2>/dev/null
iptables -D FORWARD -i %(ext_if)s -j acct 2>/dev/null
iptables -D INPUT -p tcp --dport 3128 -j acct-proxy 2>/dev/null
iptables -D OUTPUT -p tcp --sport 3128 -j acct-proxy 2>/dev/null

iptables -X acct 2>/dev/null
iptables -F acct 2>/dev/null
iptables -N acct 2>/dev/null
iptables -X acct-proxy 2>/dev/null
iptables -F acct-proxy 2>/dev/null
iptables -N acct-proxy 2>/dev/null

iptables -I FORWARD -o %(ext_if)s -j acct
iptables -I FORWARD -i %(ext_if)s -j acct
iptables -I INPUT -p tcp --dport 3128 -j acct-proxy
iptables -I OUTPUT -p tcp --sport 3128 -j acct-proxy""" % {'ext_if': ext_if}
if config.verbose:
    print command
os.system(command)

groups = {}
ngroups = 0
for client in config.clients:
    group = client & groupmask
    if groupsize[group] < 2 or len(groupsize) < 2:
        grp = ""
    else:
        try:
            grp = groups[group]
        except KeyError:
            ngroups += 1
            grp = "-%d" % ngroups
            groups[group] = grp
            mask = mgacct.format_ip(group) + "/%d" % (32 - config.groupbits)
            command = """\
iptables -X acct%(grp)s 2>/dev/null
iptables -F acct%(grp)s 2>/dev/null
iptables -N acct%(grp)s 2>/dev/null
iptables -X acct-proxy%(grp)s 2>/dev/null
iptables -F acct-proxy%(grp)s 2>/dev/null
iptables -N acct-proxy%(grp)s 2>/dev/null
iptables -A acct -s %(mask)s -j acct%(grp)s
iptables -A acct -d %(mask)s -j acct%(grp)s
iptables -A acct-proxy -s %(mask)s -j acct-proxy%(grp)s
iptables -A acct-proxy -d %(mask)s -j acct-proxy%(grp)s""" % {'mask': mask, 'grp': grp}
            if config.verbose:
                print command
            os.system(command)
    ip = mgacct.format_ip(client)
    command = """\
iptables -A acct%(grp)s -s %(ip)s
iptables -A acct%(grp)s -d %(ip)s
iptables -A acct-proxy%(grp)s -s %(ip)s
iptables -A acct-proxy%(grp)s -d %(ip)s""" % {'ip': ip, 'grp': grp}
    if config.verbose:
        print command
    os.system(command)

#!/usr/bin/python2.2
import os
import os.path
import sys

import mgacct

# Hardcoded paths
configFile = "/etc/mgacct.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgacct.parseConfig(configFile)

# Generate images
import graph

# Generate html
import html

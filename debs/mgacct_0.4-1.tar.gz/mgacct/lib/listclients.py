#!/usr/bin/python2.2
import sys
import mgacct

configFile = "/etc/mgacct.conf"
if len(sys.argv) > 1:
    configFile = sys.argv[1]
config = mgacct.parseConfig(configFile)
for ip in config.clients:
    print mgacct.format_ip(ip)

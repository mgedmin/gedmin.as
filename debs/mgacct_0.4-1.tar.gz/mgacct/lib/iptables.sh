#!/bin/sh

# Config
iptables=/sbin/iptables
listclients=/usr/lib/mgacct/listclients.py
listclients="./listclients.py ../conf/bitute.conf" #DEBUG

# Determine external interface
ext_if=`/sbin/route -n|grep '^0\.0\.0\.0'|awk '{print $8}'`
if [ -z "$ext_if" ]; then
    echo "$0: could not determine interface of the default route"
    exit 1
fi

# Detach and delete old iptables chains
$iptables -D FORWARD -o $ext_if -j acct				2>/dev/null
$iptables -D FORWARD -i $ext_if -j acct				2>/dev/null
$iptables -D INPUT -p tcp --dport 3128 -j acct-proxy		2>/dev/null
$iptables -D OUTPUT -p tcp --sport 3128 -j acct-proxy		2>/dev/null
$iptables -F acct						2>/dev/null
$iptables -F acct-proxy						2>/dev/null
$iptables -X acct						2>/dev/null
$iptables -X acct-proxy						2>/dev/null

# Create iptables chains
$iptables -N acct
$iptables -N acct-proxy

# Attach those chains
$iptables -I FORWARD -o $ext_if -j acct
$iptables -I FORWARD -i $ext_if -j acct
$iptables -I INPUT -p tcp --dport 3128 -j acct-proxy
$iptables -I OUTPUT -p tcp --sport 3128 -j acct-proxy

# Add rules for each IP
for ip in `$listclients`; do
    iptables -A acct -s $ip
    iptables -A acct -d $ip
    iptables -A acct-proxy -s $ip
    iptables -A acct-proxy -d $ip
done

#!/usr/bin/python2.2
import os
import os.path
import sys
import time

import mgacct

# Hardcoded paths
configFile = "/etc/mgacct.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgacct.parseConfig(configFile)

if not config.clients:
    # nothing to do
    sys.exit(0)

hostname = config.hostname
if not hostname:
    hostname = os.popen("hostname").read().strip()

timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

for time, foo in config.timespecs:
    fn = os.path.join(config.imgDir, "index-%s.html" % time)
    if config.verbose:
        print "Writing %s" % fn
    out = open(fn, "w")
    print >> out, "<html>"
    print >> out, "<head>"
    print >> out, "<title>%s traffic stats for last %s</title>" % (hostname, time)
    print >> out, "</head>"
    print >> out, "<body>"
    print >> out, "<table width='100%' border=0 cellspacing=0 cellpadding=0>"
    print >> out, "<tr><td>"
    for othertime, foo in config.timespecs:
        if othertime == time:
            print >> out, "[%s]" % othertime
        else:
            print >> out, "<a href='index-%s.html'>[%s]</a>" % (othertime, othertime)
    print >> out, "<a href='index-all.html'>[all]</a>"
    print >> out, "</td><td align=right>"
    print >> out, timestamp
    print >> out, "</td></tr>"
    print >> out, "</table>"
    print >> out, "<hr>"
    for client in config.clients:
        client_ip = mgacct.format_ip(client)
        imgFile = client_ip + "-%s.png" % time
        print >> out, "<a href='%s.html'><img src='%s' border=0></a><br>" % (
                      client_ip, imgFile)
    print >> out, "</body>"
    print >> out, "</html>"

for client in config.clients:
    client_ip = mgacct.format_ip(client)
    fn = os.path.join(config.imgDir, client_ip + ".html")
    if config.verbose:
        print "Writing %s" % fn
    out = open(fn, "w")
    print >> out, "<html>"
    print >> out, "<head>"
    print >> out, "<title>%s traffic stats</title>" % (client_ip)
    print >> out, "</head>"
    print >> out, "<body>"
    print >> out, "<table width='100%' border=0 cellspacing=0 cellpadding=0>"
    print >> out, "<tr><td>"
    for time, foo in config.timespecs:
        print >> out, "<a href='index-%s.html'>[%s]</a>" % (time, time)
    print >> out, "<a href='index-all.html'>[all]</a>"
    print >> out, "</td><td align=right>"
    print >> out, timestamp
    print >> out, "</td></tr>"
    print >> out, "</table>"
    print >> out, "<hr>"
    for time, foo in config.timespecs:
        imgFile = client_ip + "-%s.png" % time
        print >> out, "<a href='index-%s.html'><img src='%s' border=0></a><br>" % (
                        time, imgFile)
    print >> out, "</body>"
    print >> out, "</html>"

fn = os.path.join(config.imgDir, "index-all.html")
out = open(fn, "w")
if config.verbose:
    print "Writing %s" % fn
print >> out, "<html>"
print >> out, "<head>"
print >> out, "<title>%s traffic stats</title>" % (hostname)
print >> out, "</head>"
print >> out, "<body>"
print >> out, "<table width='100%' border=0 cellspacing=0 cellpadding=0>"
print >> out, "<tr><td>"
for time, foo in config.timespecs:
    print >> out, "<a href='index-%s.html'>[%s]</a>" % (time, time)
print >> out, "[all]"
print >> out, "</td><td align=right>"
print >> out, timestamp
print >> out, "</td></tr>"
print >> out, "</table>"
print >> out, "<hr>"
print >> out, "<table cellspacing=0 cellpadding=0>"
for client in config.clients:
    client_ip = mgacct.format_ip(client)
    print >> out, "<tr>"
    for time, foo in config.timespecs:
        imgFile = client_ip + "-%s.png" % time
        print >> out, "<td><a href='%s.html'><img src='%s' border=0></a></td>" % (
                        client_ip, imgFile)
    print >> out, "</tr>"
print >> out, "</table>"
print >> out, "</body>"
print >> out, "</html>"

#!/usr/bin/python
"""
mgstats create script

Should not be used, update can do its job.
"""
import os
import os.path
import sys

import mgstats

# Hardcoded paths
configFile = "/etc/mgstats/mgstats.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgstats.parseConfig(configFile)
graphs = {}
for item in config.items:
    graph = item[0]
    if len(item) > 1:
        param = item[1]
    else:
        param = None
    graphs.setdefault(graph, []).append(param)

# Create the necessary RRDs
for graph, params in graphs.items():
    graphFile = os.path.join(config.graphDir, graph)
    graphTime = os.stat(graphFile)[8]
    schema = None
    for param in params:
        if param is None:
            param = getattr(graphDef, 'default', None)
        rrdFile = os.path.join(config.rrdDir, graph)
        if param: rrdFile += "-%s" % mgstats.escapeFS(param)
        rrdFile += ".rrd"
        try:
            rrdTime = os.stat(rrdFile)[8]
        except OSError:
            rrdTime = graphTime - 1
        if graphTime > rrdTime:
            # need to recreate the rrd
            if not schema:
                schema = mgstats.parseGraph(graphFile).schema
            # It would be *very* good to check if the schema has changed
            command = "rrdtool create %s %s %s" % (rrdFile, schema, config.archives)
            command = command.replace("\n", " ")
            if config.verbose:
                print command
            os.system(command)

#!/usr/bin/python
import os
import os.path
import sys
import traceback

import mgstats

# Hardcoded paths
configFile = "/etc/mgstats/mgstats.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgstats.parseConfig(configFile)
graphs = {}
for item in config.items + config.collect:
    graph = item[0]
    if len(item) > 1:
        param = item[1]
    else:
        param = None
    graphs.setdefault(graph, {})[param] = 1

# Get system boot moment
try:
    import re, time
    f = open("/proc/uptime")
    m = re.match(r"^\d+(?:\.\d+)?", f.readline())
    uptime = float(m.group(0))
    boottime = str(long(time.time() - uptime))
except:
    print >> sys.stderr, "cannot determine system uptime:"
    traceback.print_exc()
    sys.exit(1)

# Update the necessary RRDs
for graph, params in graphs.items():
    graphFile = os.path.join(config.graphDir, graph)
    try:
        graphDef = mgstats.parseGraph(graphFile)
        for param in params.keys():
            if param is None:
                param = getattr(graphDef, 'default', None)
            try:
                rrdFile = os.path.join(config.rrdDir, graph)
                if param: rrdFile += "-%s" % mgstats.escapeFS(param)
                rrdFile += ".rrd"
                if not os.path.exists(rrdFile):
                    oldRrdFile = os.path.join(config.rrdDir, graph)
                    if param: oldRrdFile += "-%s" % mgstats.oldEscapeFS(param)
                    oldRrdFile += ".rrd"
                    if os.path.exists(oldRrdFile):
                        print "renaming %s to %s" % (oldRrdFile, rrdFile)
                        os.rename(oldRrdFile, rrdFile)
                    else:
                        # don't bother
                        continue
                nvars = graphDef.schema.count("DS:")    # XXX not too reliable
                result = boottime + ":U" * nvars
                command = "rrdtool update %s %s" % (rrdFile, result)
                command = command.replace("\n", " ")
                if config.verbose:
                    print command
                os.system(command)
            except Exception, e:
                if param is None:
                    print >> sys.stderr, "%s:" % graph,
                else:
                    print >> sys.stderr, "%s-%s:" % (graph, param),
                traceback.print_exc()
                continue
    except Exception, e:
        print >> sys.stderr, "%s:" % graph,
        traceback.print_exc()
        continue

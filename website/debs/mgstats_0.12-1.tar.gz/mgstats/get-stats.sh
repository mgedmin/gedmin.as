#!/bin/sh

for host in $*; do
  host=${host%/}

  echo +++ $host
  (
    mkdir -p $host
    cd $host || exit 1

    scp "$host:{/etc/mgstats/mgstats.conf,/var/lib/mgstats/*}" .
    cat >> mgstats.conf <<END
[paths]
graphdir = /etc/mgstats/graphs
rrddir = .
imgdir = html
[misc]
verbose = 0
hostname = $host
END
    mkdir html 2>/dev/null
    /usr/lib/mgstats/autograph.py mgstats.conf
    ##mozilla -remote "openUrl(file://$PWD/html/index.html, new-window)"
  )
done

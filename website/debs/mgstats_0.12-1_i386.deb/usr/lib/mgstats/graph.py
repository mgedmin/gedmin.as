#!/usr/bin/python
import os
import os.path
import sys
import traceback

import mgstats

# Hardcoded paths
configFile = "/etc/mgstats/mgstats.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgstats.parseConfig(configFile)
graphs = {}
for item in config.items:
    graph = item[0]
    args = {}
    if len(item) > 1:
        param = item[1]
        for arg in item[2:]:
            if '=' in arg:
                key, value = arg.split('=', 2)
                if len(value) > 1 and value[0] == value[-1] in ('"', "'"):
                    value = value[1:-1]
            else:
                key, value = arg, ''
            args[key] = value
    else:
        param = None
    graphs.setdefault(graph, []).append((param, args))

# Update the necessary RRDs
for graph, params in graphs.items():
    graphFile = os.path.join(config.graphDir, graph)
    try:
        graphDef = mgstats.parseGraph(graphFile)
        for param, args in params:
            if param is None:
                param = getattr(graphDef, 'default', None)
            try:
                rrdFile = os.path.join(config.rrdDir, graph)
                if param: rrdFile += "-%s" % mgstats.escapeFS(param)
                rrdFile += ".rrd"
                if not os.path.exists(rrdFile):
                    oldRrdFile = os.path.join(config.rrdDir, graph)
                    if param: oldRrdFile += "-%s" % mgstats.oldEscapeFS(param)
                    oldRrdFile += ".rrd"
                    if os.path.exists(oldRrdFile):
                        print >> sys.stderr, "please rename %s to %s" % (oldRrdFile, rrdFile)
                        rrdFile = oldRrdFile
                    else:
                        print >> sys.stderr, "%s does not exist, skipping" % rrdFile
                        continue
                for time, timespec in config.timespecs:
                    imgFile = os.path.join(config.imgDir, graph)
                    if param: imgFile += "-%s" % mgstats.escapeFS(param)
                    imgFile += "-%s.png" % time
                    vars = {}
                    if args:
                        vars.update(args)
                    vars['FILENAME'] = rrdFile
                    vars['PARAM'] = param or ''
                    vars['INTERVAL'] = time
                    if hasattr(graphDef, 'graphprepare'):
                        code = compile('def graph_prepare():\n' +
                                       graphDef.graphprepare +
                                       '\ngraph_prepare()', graphFile,
                                       'exec')
                        eval(code, {'vars': vars, 'param': param, 'args': args})
                    rrdGraph = graphDef.graph
                    for key, value in vars.items():
                        rrdGraph = rrdGraph.replace("$(%s)" % key, value)
                    if config.lazy: timespec += " -lazy"
                    command = "rrdtool graph %s %s %s > /dev/null" % (timespec,
                                             imgFile, rrdGraph)
                    command = command.replace("\n", " ")
                    if config.verbose:
                        print command
                    os.system(command)
                    oldImgFile = os.path.join(config.imgDir, graph)
                    if param: oldImgFile += "-%s" % mgstats.oldEscapeFS(param)
                    oldImgFile += "-%s.png" % time
                    if oldImgFile != imgFile and os.path.exists(oldImgFile):
                        if config.verbose:
                            print "Removing %s" % oldImgFile
                        os.unlink(oldImgFile)
            except Exception, e:
                if param is None:
                    print >> sys.stderr, "%s:" % graph,
                else:
                    print >> sys.stderr, "%s-%s:" % (graph, param),
                traceback.print_exc()
                continue
    except Exception, e:
        print >> sys.stderr, "%s:" % graph,
        traceback.print_exc()
        continue

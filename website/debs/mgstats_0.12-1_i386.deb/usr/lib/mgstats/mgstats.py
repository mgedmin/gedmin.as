"""mgstats common routines"""

#
# Config file
#

class Config:

    # Pathnames
    graphDir = "/etc/mgstats/graphs"
    rrdDir = "/var/lib/mgstats"
    imgDir = "/var/www/mgstats"

    # Misc
    verbose = 0
    autoGraph = 1
    lazy = 0
    hostname = ""

    # RRD archives
    timespecs = (('day',   '-x HOUR:1:HOUR:24:HOUR:1:0:%H'),
                 ('week',  '-s end-1week'),
                 ('month', '-s end-1month'),
                 ('year',  '-s end-1year -x MONTH:1:MONTH:12:MONTH:1:2592000:%b'))
    archives = """\
RRA:AVERAGE:0.5:1:600
RRA:AVERAGE:0.5:6:700
RRA:AVERAGE:0.5:24:775
RRA:AVERAGE:0.5:288:797
RRA:MAX:0.5:1:600
RRA:MAX:0.5:6:700
RRA:MAX:0.5:24:775
RRA:MAX:0.5:288:797
"""

class ConfigError(Exception):
    """mgstats config file error"""
    pass

def splitwords(line):
    """Like line.split() only keeps quoted words together."""
    res = []
    state = 0
    idx = 0
    for c in line:
        # state 0: whitespace
        #   nonblank -> state 1 & mark start
        #   '        -> state 2 & mark start
        #   "        -> state 3 & mark start
        if state == 0 and not c.isspace():
            start = idx
            if c == '"':   state = 3
            elif c == "'": state = 2
            else:          state = 1
        # state 1: unquoted word
        #   blank    -> state 0 & add word
        #   '        -> state 2
        #   "        -> state 3
        #   EOF      -> add word
        elif state == 1 and c.isspace():
            res.append(line[start:idx])
            state = 0
        elif state == 1 and c == "'":
            state = 2
        elif state == 1 and c == '"':
            state = 3
        # state 2: single quoted
        #   '        -> state 1
        #   EOF      -> add word
        elif state == 2 and c == "'":
            state = 1
        # state 3: double quoted
        #   '        -> state 1
        #   EOF      -> add word
        elif state == 3 and c == '"':
            state = 1
        idx += 1
    # EOF: states 1, 2, 3 -> add word
    if state != 0:
        res.append(line[start:])
    return res

def parseConfig(filename="/etc/mgstats/mgstats.conf"):
    """Parses mgstats config file and returns a list of lists of the form
    [graph_name] or [graph_name, parameter_value]."""

    cfg = Config()
    cf = open(filename)
    cfg.items = []
    cfg.collect = []
    section = 'graphs'
    for line in cf.readlines():
        idx = line.find('#')
        if idx >= 0: line = line[:idx]
        line = line.strip()
        if not line: continue
        if line[0] == '[':
            if line[-1] != ']':
                raise ConfigError, 'Bad section name: %s' % line
            section = line[1:-1].strip().lower()
            continue
        if section == 'graphs':
            arr = splitwords(line)
            cfg.items.append(arr)
        elif section == 'collect':
            arr = splitwords(line)
            cfg.collect.append(arr)
        elif section == 'paths':
            key, value = line.split('=')
            key = key.strip().lower()
            value = value.strip()
            if key == "graphdir": cfg.graphDir = value
            elif key == "rrddir": cfg.rrdDir = value
            elif key == "imgdir": cfg.imgDir = value
        elif section == 'misc':
            key, value = line.split('=')
            key = key.strip().lower()
            value = value.strip()
            if key == "verbose": cfg.verbose = int(value)
            elif key == "autograph": cfg.autoGraph = int(value)
            elif key == "lazy": cfg.lazy = int(value)
            elif key == "hostname": cfg.hostname = value
        # XXX: perform some validation and show nice errors, not exceptions
    return cfg

#
# Graph definitions
#

class GraphDef:
    pass

def parseGraph(filename):
    """Parses mgstats graph definition file."""

    import re

    result = GraphDef()
    title = None
    gf = open(filename)
    lineno = 0
    header = re.compile(r"^([-a-zA-Z0-9]+):(.*)").match
    for line in gf.readlines():
        lineno += 1
        if line[0] in ('#', '\r', '\n'): continue
        m = header(line)
        if m:
            title = m.group(1).lower()
            value = m.group(2).strip()
            setattr(result, title, value)
        elif line[0].isspace():
            if not title:
                raise ConfigError, "Syntax error in %s:%d" % (filename, lineno)
            if value and value[-1] != '\n':
                value += '\n'
            value += line
            setattr(result, title, value)
        else:
            raise ConfigError, "Syntax error in %s:%d" % (filename, lineno)
    return result

#
# Misc utils
#

def oldEscapeFS(fn):
    """Escape file-system unsafe characters for file names (old version)."""
    return fn.replace("%", '%25').replace("/", '%2f')

def escapeFS(fn):
    """Escape file-system unsafe characters for file names."""
    return fn.replace("+", '++').replace("/", '+_')

def escapeHtml(fn):
    """Escape file names for inclusion into HTML."""
    return fn.replace('&', '&amp;')\
             .replace('"', '&quot;')\
             .replace('<', '&lt;')\
             .replace('>', '&gt;')\
             .replace('%', '%25')


#!/usr/bin/python
import os
import os.path
import sys
import time

import mgstats

# Hardcoded paths
configFile = "/etc/mgstats/mgstats.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgstats.parseConfig(configFile)
items = config.items
graphDefs = {}
for item in items:
    graph = item[0]
    if not graphDefs.has_key(graph):
        graphFile = os.path.join(config.graphDir, graph)
        graphDefs[graph] = mgstats.parseGraph(graphFile)

hostname = config.hostname
if not hostname:
    hostname = os.popen("hostname").read().strip()

timestamp = time.strftime('%Y-%m-%d %H:%M:%S %z')

for time, foo in config.timespecs:
    fn = os.path.join(config.imgDir, "index-%s.html" % time)
    if config.verbose:
        print "Writing %s" % fn
    out = open(fn, "w")
    print >> out, '<html>'
    print >> out, '<head>'
    print >> out, '<title>%s stats for last %s</title>' % (hostname, time)
    print >> out, '</head>'
    print >> out, '<body>'
    print >> out, '<table cellspacing=0 cellpadding=0 width="100%">'
    print >> out, '<tr><td align=left>'
    for othertime, foo in config.timespecs:
        if othertime == time:
            print >> out, '[%s]' % othertime
        else:
            print >> out, '<a href="index-%s.html">[%s]</a>' % (othertime, othertime)
    print >> out, '<a href="index.html">[all]</a>'
    print >> out, '</td><td align=right>'
    print >> out, timestamp
    print >> out, '</td></tr>'
    print >> out, '</table>'
    print >> out, '<hr>'
    for item in items:
        graph = item[0]
        try: param = item[1]
        except IndexError: param = getattr(graphDefs[graph], 'default', None)
        basename = graph
        if param: basename += "-%s" % mgstats.escapeFS(param)
        basename = mgstats.escapeHtml(basename)
        imgFile = basename + "-%s.png" % time
        title = graphDefs[graph].title
        if param: title += ' (%s, %s)' % (param, time)
        else: title += ' (%s)' % time
        title = mgstats.escapeHtml(title)
        print >> out, "<a href='%s.html'><img src='%s' border=0 width=497 height=196 alt='%s'></a><br>" % (
                     basename, imgFile, title)
    print >> out, "</body>"
    print >> out, "</html>"

for item in items:
    graph = item[0]
    try: param = item[1]
    except IndexError: param = getattr(graphDefs[graph], 'default', None)
    title = graphDefs[graph].title
    basename = graph
    if param: basename += "-%s" % mgstats.escapeFS(param)
    fn = os.path.join(config.imgDir, basename + ".html")
    if config.verbose:
        print "Writing %s" % fn
    out = open(fn, "w")
    print >> out, '<html>'
    print >> out, '<head>'
    print >> out, '<title>%s %s</title>' % (hostname, title)
    print >> out, '</head>'
    print >> out, '<body>'
    print >> out, '<table cellspacing=0 cellpadding=0 width="100%">'
    print >> out, '<tr><td align=left>'
    for time, foo in config.timespecs:
        print >> out, '<a href="index-%s.html">[%s]</a>' % (time, time)
    print >> out, '<a href="index.html">[all]</a>'
    print >> out, '</td><td align=right>'
    print >> out, timestamp
    print >> out, '</td></tr>'
    print >> out, '</table>'
    print >> out, '<hr>'
    basename = mgstats.escapeHtml(basename)
    for time, foo in config.timespecs:
        imgFile = basename + "-%s.png" % time
        title = graphDefs[graph].title
        if param: title += ' (%s, %s)' % (param, time)
        else: title += ' (%s)' % time
        title = mgstats.escapeHtml(title)
        print >> out, '<a href="index-%s.html"><img src="%s" border=0 width=497 height=196 alt="%s"></a><br>' % (
                        time, imgFile, title)
    print >> out, '</body>'
    print >> out, '</html>'
    basename = graph
    if param: basename += "-%s" % mgstats.oldEscapeFS(param)
    oldFn = os.path.join(config.imgDir, basename + ".html")
    if fn != oldFn and os.path.exists(oldFn):
        if config.verbose:
            print "Removing %s" % oldFn
        os.unlink(oldFn)

fn = os.path.join(config.imgDir, "index.html")
out = open(fn, "w")
if config.verbose:
    print "Writing %s" % fn
print >> out, '<html>'
print >> out, '<head>'
print >> out, '<title>%s stats</title>' % (hostname)
print >> out, '</head>'
print >> out, '<body>'
print >> out, '<table cellspacing=0 cellpadding=0 width="100%">'
print >> out, '<tr><td align=left>'
for time, foo in config.timespecs:
    print >> out, '<a href="index-%s.html">[%s]</a>' % (time, time)
print >> out, '[all]'
print >> out, '</td><td align=right>'
print >> out, timestamp
print >> out, '</td></tr>'
print >> out, '</table>'
print >> out, '<hr>'
print >> out, '<table cellspacing=0 cellpadding=0>'
for item in items:
    graph = item[0]
    try: param = item[1]
    except IndexError: param = getattr(graphDefs[graph], 'default', None)
    basename = graph
    if param: basename += "-%s" % mgstats.escapeFS(param)
    basename = mgstats.escapeHtml(basename)
    print >> out, '<tr>'
    for time, foo in config.timespecs:
        imgFile = basename + "-%s.png" % time
        title = graphDefs[graph].title
        if param: title += ' (%s, %s)' % (param, time)
        else: title += ' (%s)' % time
        title = mgstats.escapeHtml(title)
        print >> out, '<td><a href="%s.html"><img src="%s" border=0 width=497 height=196 alt="%s"></a></td>' % (
                        basename, imgFile, title)
    print >> out, "</tr>"
print >> out, '</table>'
print >> out, '</body>'
print >> out, '</html>'

#!/usr/bin/python
import os
import os.path
import sys
import traceback

import mgstats

# Hardcoded paths
configFile = "/etc/mgstats/mgstats.conf"

if len(sys.argv) > 1:
    configFile = sys.argv[1]

# Parse config file
config = mgstats.parseConfig(configFile)
graphs = {}
for item in config.items + config.collect:
    graph = item[0]
    if len(item) > 1:
        param = item[1]
    else:
        param = None
    graphs.setdefault(graph, {})[param] = 1

# Update the necessary RRDs
for graph, params in graphs.items():
    graphFile = os.path.join(config.graphDir, graph)
    try:
        graphDef = mgstats.parseGraph(graphFile)
        for param in params.keys():
            if param is None:
                param = getattr(graphDef, 'default', None)
            try:
                rrdFile = os.path.join(config.rrdDir, graph)
                if param: rrdFile += "-%s" % mgstats.escapeFS(param)
                rrdFile += ".rrd"
                if not os.path.exists(rrdFile):
                    oldRrdFile = os.path.join(config.rrdDir, graph)
                    if param: oldRrdFile += "-%s" % mgstats.oldEscapeFS(param)
                    oldRrdFile += ".rrd"
                    if os.path.exists(oldRrdFile):
                        print "renaming %s to %s" % (oldRrdFile, rrdFile)
                        os.rename(oldRrdFile, rrdFile)
                    else:
                        # need to create the rrd
                        command = "rrdtool create %s %s %s" % (rrdFile,
                                                 graphDef.schema, config.archives)
                        command = command.replace("\n", " ")
                        if config.verbose:
                            print command
                        os.system(command)
                code = compile('def update():\n' + graphDef.update, graphFile,
                               'exec')
                eval(code)  # FIXME: limit locals, globals
                result = update()
                command = "rrdtool update %s %s" % (rrdFile, result)
                command = command.replace("\n", " ")
                if config.verbose:
                    print command
                os.system(command)
            except Exception, e:
                if param is None:
                    print >> sys.stderr, "%s:" % graph,
                else:
                    print >> sys.stderr, "%s-%s:" % (graph, param),
                traceback.print_exc()
                continue
    except Exception, e:
        print >> sys.stderr, "%s:" % graph,
        traceback.print_exc()
        continue

if config.autoGraph:
    import autograph

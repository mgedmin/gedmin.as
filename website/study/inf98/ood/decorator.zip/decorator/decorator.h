#ifndef DECORATOR_H_INCLUDED
#define DECORATOR_H_INCLUDED

#include <string>

// --------------------------------------------------------------------------

/**
 * @addtogroup interfaces Interfeisai
 * @{
 */

class Decorator;

/**
 * Abstraktus dokumentas.  Galima j� per�i�rin�ti, spausdinti, redaguoti.
 *
 * Taip pat pateikiamos funkcijos darbui su dekoratoriais.
 */
class Document {
public:

    /** Konstruktorius. */
    Document() {}

    /** Virtualus destruktorius. */
    virtual ~Document() = 0;

    // Darbas su dokumentais

    /** Galime dokument� per�i�r�ti. */
    virtual void view() = 0;

    /** Galime dokument� spausdinti. */
    virtual void print() = 0;

    /** Galime dokument� redaguoti. */
    virtual void edit() = 0;

    // Darbas su dekoratoriais

    /**
     * Gr��ina nurodyto tipo dekoratori�.
     *
     * Jei dekoratori� grandin�je yra daugiau nei vienas nurodyto tipo
     * dekoratorius, gra�ina i�ori�kiausi�.  Jei nurodyto tipo dekoratoriaus
     * n�ra, gr��ina 0.
     *
     * Taisykl�s primena dynamic_cast<>, t.y., jei objektas yra dekoruotas ne
     * pa�ios DecoratorType klas�s, bet i� jos i�vestos poklas�s dekoratoriumi,
     * jis bus gr��inamas.
     *
     * Jei norite rasti visus nurodyto tipo dekoratorius, darykite �itaip:
     *
     * <pre>
     *     for (Document* tmp = document;
     *          DecoratorType* d = tmp->decorator<DecoratorType>();
     *          tmp = d->next())
     *     {
     *         // do something with d
     *     }
     * </pre>
     */
    template<typename DecoratorType> DecoratorType* decorator();

    /**
     * Gr��ina dokument� be nurodyto tipo dekoratoriaus.
     *
     * Parametras all sako, ar reikia i�mesti visus nurodyto tipo dekoratorius
     * (jei true), ar tik i�ori�kiausi� (jei false).
     *
     * I�mesti dekoratoriai (jei toki� buvo) sunaikinami.
     *
     * Taisykl�s primena dynamic_cast<>, t.y., jei objektas yra dekoruotas ne
     * pa�ios DecoratorType klas�s, bet i� jos i�vestos poklas�s dekoratoriumi,
     * jis bus i�metamas.
     */
    template<typename DecoratorType> Document* unwrap(bool all);

    /**
     * Gr��ina kit� objekt� dekoratori� grandin�je.  Jei objektas nedekoruotas,
     * gr��ina 0.
     */
    virtual Document* next() const { return 0; }

private:

    /**
     * Nustato kit� objekt� dekoratori� grandin�je.
     *
     * Funkcija reikalinga norint realizuoti dekoratoriaus i�metim� i�
     * s�ra�o unwrap metode.
     */
    virtual void setNext(Document* next) {}

};

/// @}

template<typename DecoratorType>
DecoratorType* Document::decorator()
{
    if (DecoratorType* p = dynamic_cast<DecoratorType*>(this))
	return p;
    else if (Document * n = next())
	return n->decorator<DecoratorType>();
    else
	return 0;
}

template<typename DecoratorType>
Document* Document::unwrap(bool all)
{
    if (dynamic_cast<DecoratorType*>(this)) {
	Document * n = next();
	setNext(0);
	delete this;
	return n;
    } else {
	setNext(next()->unwrap<DecoratorType>(all));
	return this;
    }
}

/// @{

/**
 * Abstraktus dekoratorius.
 */
class Decorator : public Document {

    Document* next_;		///< Dekoruotas objektas

public:

    /**
     * Konstruktorius.
     *
     * Dekoruotas objektas @a next gali b�ti 0, bet tik tuo atveju, jei
     * dekoratori� naudosite kaip parametr� unwrap arba decorator funkcijoms ir
     * niekam daugiau.
     */
    Decorator(Document* next)
	: next_(next) {}

    /** Destruktorius.  Taip pat sunaikina ir dekoruot� objekt�. */
    ~Decorator() = 0;

    // Darbas su dokumentu
    void view() { next_->view(); }
    void print() { next_->print(); }
    void edit() { next_->edit(); }

    // Darbas su dekoratoriais
    Document* next() const { return next_; }

private:

    void setNext(Document* next) { next_ = next; }

};

/// @}

// --------------------------------------------------------------------------

/**
 * @addtogroup documents Konkret�s dokumentai
 * @{
 */

/**
 * Tekstinis dokumentas.
 */
class TextDocument : public Document {
public:

    // Darbas su dokumentais
    void view();
    void print();
    void edit();

};

/**
 * Paveiksliukas.
 */
class Image : public Document {
public:

    // Darbas su dokumentais
    void view();
    void print();
    void edit();

};

/// @}

// --------------------------------------------------------------------------

/**
 * @addtogroup decorators Konkret�s dekoratoriai
 * @{
 */

/**
 * Nemodifikuojamas dokumentas.
 */
class ReadOnly : public Decorator
{
public:

    explicit ReadOnly(Document* next)
	: Decorator(next) {}

    void edit();

};

/**
 * Anotacija skaitytojui.
 */
class Annotation : public Decorator
{
    std::string annotation_;

public:

    Annotation(Document* next, const std::string& annotation)
	: Decorator(next), annotation_(annotation) {}

    void view();
    void print();

    // Papildomas funkcionalumas

    /** Gr��ina anotacij�. */
    const std::string& annotation() const
    { return annotation_; }

    /** Pakei�ia anotacij�. */
    void changeAnnotation(const std::string& annotation)
    { annotation_ = annotation; }

};

/// @}

// --------------------------------------------------------------------------

#endif

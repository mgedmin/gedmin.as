class Document:
    """
    Abstraktus dokumentas.  Subklas�s tur�t� realizuoti metodus view,
    printIt bei edit.
    """

    def decorator(self, subtype):
        """Gr��ina nurodyto tipo dekoratori�.

        Jei dekoratori� grandin�je yra daugiau nei vienas nurodyto tipo
        dekoratorius, gra�ina i�ori�kiausi�.  Jei nurodyto tipo dekoratoriaus
        n�ra, gr��ina None.
        """
        return None

    def allDecorators(self, subtype):
        """Gr��ina visus tipo dekoratorius s�ra�e."""
        return []

    def unwrap(self, subtype, all):
        """Gr��ina dokument� be nurodyto tipo dekoratoriaus.

        Parametras all sako, ar reikia i�mesti visus nurodyto tipo dekoratorius
        (jei true), ar tik i�ori�kiausi� (jei false).
        """
        return self

    def next(self):
        """Gr��ina kit� objekt� dekoratori� grandin�je.  Jei objektas
        nedekoruotas, gr��ina None
        """
        return None

class Decorator(Document):
    """Abstraktus dekoratorius"""

    def __init__(self, next):
        """Konstruktorius."""
        self._next = next

    def __getattr__(self, attr):
        """Deleguojame pri�jim� prie vis� kit� atribut� tikrajam objektui."""
        return getattr(self._next, attr)

    def decorator(self, subtype):
        if isinstance(self, subtype):
            return self
        else:
            return self._next.decorator(subtype)

    def allDecorators(self, subtype):
        if isinstance(self, subtype):
            result = [self]
        else:
            result = []
        return result + self._next.allDecorators(subtype)

    def unwrap(self, subtype, all):
        if isinstance(self, subtype):
            if all:
                return self._next.unwrap(subtype, all)
            else:
                return self._next
        else:
            return self._next.unwrap(subtype, all)

    def next(self):
        return self._next

class TextDocument(Document):
    """Tekstinis dokumentas"""

    def view(self):
        print "tekstinio dokumento per�i�ra"
    def printIt(self):
        print "tekstinio dokumento spausdinimas"
    def edit(self):
        print "tekstinio dokumento redagavimas"

class Image(Document):
    """Paveiksliukas"""

    def view(self):
        print "paveiksliuko per�i�ra"
    def printIt(self):
        print "paveiksliuko spausdinimas"
    def edit(self):
        print "paveiksliuko redagavimas"

class ReadOnly(Decorator):
    """Nemodifikuojamas dokumentas"""

    def edit(self):
        print "negalima redaguoti �io dokumento!"

class Annotation(Decorator):
    """Anotacija skaitytojui"""

    def __init__(self, next, annotation):
        """Konstruktorius"""
        Decorator.__init__(self, next)
        self._annotation = annotation

    def view(self):
        self.next().view()
        print "  anotacija:", self._annotation

    def printIt(self):
        self.next().printIt()
        print "  anotacija:", self._annotation

    def annotation(self):
        """Gr��ina anotacij�"""
        return self._annotation

    def changeAnnotation(self, annotation):
        """Pakei�ia anotacij�"""
        self._annotation = annotation

if __name__ == "__main__":

    # Sukuriame objektus
    txt = TextDocument()
    img = Image()

    # Bazinis funkcionalumas
    print "* Bazinis funkcionalumas";
    txt.view();
    txt.printIt();
    txt.edit();
    img.view();
    img.printIt();
    img.edit();
    print

    # Prikabiname dekoratorius
    txt = Annotation(txt, "�domus dokumentas");
    txt = ReadOnly(txt);

    img = Annotation(img, "gra�us paveiksliukas");
    img = Annotation(img, "o man nepatiko");

    # Bazinis funkcionalumas su dekoratoriais
    print "* Bazinis funkcionalumas su dekoratoriais";
    txt.view();
    txt.printIt();
    txt.edit();
    img.view();
    img.printIt();
    img.edit();
    print

    # Papildomas funkcionalumas
    print "* Papildomas funkcionalumas: pakeiskime anotacij�";
    if 0: # galima taip
        a = txt.decorator(Annotation)
        if a:
            a.changeAnnotation("o gal ir nelabai �domus");
            txt.view()
    else: # o galima �itaip
        try:
            txt.changeAnnotation("o gal ir nelabai �domus");
            txt.view()
        except AttributeError:
            pass
    print

    # Parodykime visas anotacijas
    print "* Pereikime per visus vieno tipo dekoratorius";
    for d in img.allDecorators(Annotation):
        print "radau anotacij�:", d.annotation()
    print

    # Nuimkime dekoratori�
    print "* Nuimkime ReadOnly dekoratori�";
    txt = txt.unwrap(ReadOnly, 1);
    txt.edit();
    print


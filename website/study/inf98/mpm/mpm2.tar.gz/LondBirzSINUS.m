% test of robust single layer perceptron in the stock market closing index prediction task
% author           Sarunas Raudys    Phone: (5) 2109-341  <raudys@das.mii.lt>
% [ER,yt,y_prognozeT,ym,y_prognozeM]=LondBirzSINUS(100,400,500,600,[1,4,10,11,12,20],20,0.1,3,1,0.5);
% mset:0.234668 rost:0.955397 er:0.077868  rrt:0.982702  sigt:0.115167  %%%%%%%  WITH ROBUST SLP MSE IS  0.234668 /0.115167  = 2.0376  TIMES SMALLER
% mokymui imu 400 vektoriu (101-500), o testui - 600 vektoriu (501-1100) ir pozymiu [1,4,10,11,12,20] dvieju dienu istorija

function [ER,yt,y_prognozeT,ym,y_prognozeM]=LondBirzSINUS(Ns,Nmok,Nt1,Ntest,fea,iter,eta,PROC,alfa1,alfa2)
load birza 
B=birza(1:end,fea); clear birza  % nuskaitau duomenis
[nm,p]=size(B);
%y=B(Ns+6:nm,1)-B(Ns+4:nm-2,1); % cia  rodiklis butu dviem dienom i prieki
y=B(1+5:nm-1,1)-B(1+4:nm-2,1); % cia  rodiklis (birzos "uzdarymo indeksas") vienai dienai i prieki
%   b=[B(Ns+4:nm-1,:),B(Ns+3:nm-2,:),B(Ns+2:nm-3,:),B(Ns+1:nm-4,:),B(Ns+0:nm-5,:)];b=[b,y];   %   suformuoju mokymui+test duomenu lentele is 4 dienu istorijos
b=[B(1+4:nm-2,:),B(1+3:nm-3,:)];b=[b,y];   %   suformuoju mokymui+test duomenu lentele is 2 dienu istorijos

[N,p]=size(b);	
c=(b-ones(N,1)*mean(b(Ns+1:Ns+Nmok,:)))./(ones(N,1)*std(b(Ns+1:Ns+Nmok,:))); clear b % atimu vidurkius ir dalinu is standartiniu nukrypimu
S1=cov(c(Ns+1:Ns+Nmok,1:p-1));[T,D,V]=svd(S1);Tr=T*inv(sqrtm(D+0.000001*eye(p-1)));  % Surandu "balinancia" duomenu matrica
C=[c(:,1:p-1)*Tr,c(:,p)];  %  atbalinu duomenis - pasuku-dekoreliuoju is sunormuoju dispersijas  (tik x (iksus))

S=cov(C(Ns+1:Ns+Nmok,1:p));S1=S(1:p-1,1:p-1);w=S(p,1:p-1)*inv(S1);prt=C(Nt1+1:Nt1+Ntest,1:p-1)*w';yt=C(Nt1+1:Nt1+Ntest,p);
rostand=corrcoef([prt,yt]);rst=rostand(1,2);mset=sqrt(((prt-yt)'*(prt-yt))/Ntest); % sos 2 eilutes buvo standartiniu mse ir kor koeficiento  skaiciavimas


%  cia is pagal mokymo duomenis suskaiciavau vidurki ir ji is visu pozymiu atemiau.
%  paskui "pasukau" duomenis ir juos " normalizavau" taip, kad gautusi nekoreliuoti ir turetu vienodas dispersijas

am=C(Ns+1:Ns+Nmok,1:p-1);ym=C(Ns+1:Ns+Nmok,p);% suformuoju mokymo dali
at=C(Nt1+1:Nt1+Ntest,1:p-1);yt=C(Nt1+1:Nt1+Ntest,p);  % suformuoju testine dali
figure(1);clf;plot([1:N]',c(:,p),'y:',[Ns+1:Ns+Nmok]',ym,'m-',[Nt1+1:Nt1+Ntest]',yt,'c-')  % nupiesiu duomenis geltonai, is ju mokymo ruzavi, o testiniai - melyni

Ss=cov([am,ym]);S1=Ss(1:p-1,1:p-1);w=S(p,1:p-1)*inv(S1);  % startiniai robust SLP mokymo svoriai - standartine regresija

[WBEST,ER,ITER]=robslpsinus(am,ym,iter,eta,[w,0],PROC,alfa1);[WBEST,ER,ITER]=robslpsinus(am,ym,iter,eta,WBEST(end,:),PROC,alfa2);  
% cia 2 kart panaudojau robust slp su vis siaurejanciu langu: alfa1 ir alfa2
 
%[W,WBEST,ER,ET]=linearSLP(am,ym,am,ym,iter,eta,zeros(1,p));  % cia standartinis tiesinis SLP pabandymui, cia startas nuo [0 0 ... 0 0];

figure(2);clf;hold off;plot([1:iter],ER(end,:),'g-');   % piesiu klaidos mokymo kitimo grafika 
y_prognozeM=am*WBEST(end,1:p-1)'+WBEST(end,p);y_prognozeT=at*WBEST(end,1:p-1)'+WBEST(end,p); % SLP prognoze mokymo (M) ir test (T) duomenims
figure(3);clf;plot([Ns+1:Ns+Nmok],ym','m-',[Nt1+1:Nt1+Ntest],yt','c-',[Ns+1:Ns+Nmok],y_prognozeM','r:',[Nt1+1:Nt1+Ntest],y_prognozeT','b:') % piesiu signala ir prognozes
figure(4);clf;plot(ym,y_prognozeM,'r.',yt,y_prognozeT,'b.')  % plot signalas (x sasis) versus prognoze(y asis)
rrt=corrcoef([yt,y_prognozeT]);sigt=sqrt(sum((yt-y_prognozeT).^2)/Ntest); % suskaiciuju dar kart test duomenim mean square error mse ir koreliacijos koeficienta
fprintf(1,'mset:%3.6f rost:%3.6f er:%3.6f  rrt:%2.6f  sigt:%2.6f  \n',mset, rst, min(ER(end,:)),rrt(1,2),sigt);  % spausdinu rezultatus
%   Atspuasdinu minimalias mokymo ir test paklaidas, bei koreliacijos koefoicienta teste
return

/*
 * Copyright (c) 1998 Marius Gedminas <mgedmin@pub.osf.lt>
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write to the Free Software
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define _GNU_SOURCE	/* glibc2 required for `getdelim' */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

#include <newt.h>	/* newt library from Red Hat */

#include "pkg.h"
#include "util.h"

#define VERSION "0.1.2"

/* Max window size */
#define MAX_WND_W	255

/* Utils */

char *
concat_and_free(char * s1, char * s2)
{
  char * buf;
  int len;
  len = strlen(s1) + strlen(s2);
  buf = (char *) malloc(len + 1);
  strcpy(buf, s1);
  strcat(buf, s2);
  free(s1);
  free(s2);
  return buf;
}

/* Globals */

int wnd_w, wnd_h;
int qwnd_w, qwnd_h;

pkg pkgList = NULL, pkgSubList = NULL;
pkg pkgListI = NULL;
pkg pkgListA = NULL;
char * lastDir = NULL;
newtComponent label, listbox;

/* `Chdir'ing */

void
allPackages(void)
{
  pkg p;
  char buf[MAX_WND_W+1];
  newtListboxClear(listbox);
  pkgFreeList(pkgSubList); pkgSubList = NULL;
  newtLabelSetText(label, "All packages");
  p = pkgFindGroup(pkgList, "");
  if (p)
    {
      pkgCustomText(p, buf, "<Groups>", wnd_w-7, 16+wnd_w-31);
      newtListboxAddEntry(listbox, buf, p);
    }
  p = pkgList;
  while (p) 
    {
      if (p->line)
        {
          pkgText(p, buf, wnd_w-7, 16, wnd_w-31);
          newtListboxAddEntry(listbox, buf, p);
	}
      p = p->next;
    }
  lastDir = NULL;
}

void
groupPackages(pkg g)
{
  pkg p;
  char *curDir = g->summary;
  char buf[MAX_WND_W+1];
  newtListboxClear(listbox);
  if (*g->summary == '\0')
    {
      newtLabelSetText(label, "/");
      p = pkgFindGroup(pkgList, "");
      pkgCustomText(p, buf, "<..>", wnd_w-7, 16+wnd_w-31);
      newtListboxAddEntry(listbox, buf, NULL);
    }
  else
    {
      newtLabelSetText(label, g->summary);
      p = pkgFindGroup(pkgList, g->group);
      pkgCustomText(g, buf, "<..>", wnd_w-7, 16+wnd_w-31);
      newtListboxAddEntry(listbox, buf, p);
    }
  pkgFreeList(pkgSubList); pkgSubList = NULL; /* g is also destroyed */
  pkgSubList = pkgExtractList(pkgList, curDir);
  p = pkgSubList;
  while (p) 
    {
      pkgText(p, buf, wnd_w-7, 16, wnd_w-31);
      newtListboxAddEntry(listbox, buf, p);
      p = p->next;
    }
  if (lastDir)
    {
      p = pkgFindGroup(pkgSubList, lastDir);
      if (p)
        newtListboxSetCurrentByKey(listbox, p);
    }
  lastDir = curDir;
}

void
doRefresh()
{
  if (lastDir)
    groupPackages(pkgFindGroup(pkgList, lastDir));
  else
    allPackages();
}

/* Operations */

int
doQuery(pkg p, const char * atitle, const char * cmd, int add_p)
{
  FILE *f;
  char * line;
  size_t N;
  int err;
  char * title; 
  char * query; 
  newtComponent form = NULL, textbox;
  struct newtExitStruct es;
  int result = 0;

  if (p->fname)
    {
      title = concat(atitle, p->fname, NULL);  
      query = concat("rpm ", cmd, add_p ? " -p " : " ", p->fname, " 2>&1", NULL);  
    }
  else
    {
      title = concat(atitle, p->name, "-", p->version, "-", p->release, NULL);  
      query = concat("rpm ", cmd, " ", p->name, "-", p->version, "-", p->release, " 2>&1", NULL);  
    }
  newtCenteredWindow(qwnd_w, qwnd_h, title);
  newtPushHelpLine("Enter, F12 - Exit");
  form = newtForm(NULL, NULL, 0);
  textbox = newtTextbox(0, 0, qwnd_w+1, qwnd_h, NEWT_TEXTBOX_SCROLL | NEWT_TEXTBOX_WRAP);
  
  newtPushHelpLine(query);
  newtRefresh();
  f = popen(query, "r");
  line = NULL; N = 0;
  err = getdelim(&line, &N, EOF, f);
  pclose(f);
  
  if (err < 0 || line == NULL || *line == '\0')
    { /* Empty output (in fact err will be -1 and line will contain garbage) */
      if (line) free(line);
      line = concat("Ok.", NULL); 
      result = 1;
    }
  
  newtPopHelpLine();
  newtTextboxSetText(textbox, line);
  
  newtFormAddComponent(form, textbox);
  newtFormAddHotKey(form, NEWT_KEY_F1);
  newtFormAddHotKey(form, NEWT_KEY_ENTER);
  /* newt-0.21 text widget crashes on these keys so we trap them */
  newtFormAddHotKey(form, NEWT_KEY_PGUP); 
  newtFormAddHotKey(form, NEWT_KEY_PGDN);
  do {
    newtFormRun(form, &es); 
  } while (es.reason == NEWT_EXIT_HOTKEY 
	   && (es.u.key == NEWT_KEY_PGUP || es.u.key == NEWT_KEY_PGDN));
  newtPopHelpLine();
  newtPopWindow();
  newtFormDestroy(form);
  free(line);
  free(query);
  free(title);
  return result;
}

int
doQuery2(pkg p, const char * atitle, const char * txt1, const char * cmd1, 
	 int long1, ...)
{
  FILE *f;
  char * line, * txt;
  size_t N;
  int err;
  char * title; 
  char * query; 
  char * caps = NULL;
  newtComponent form = NULL, textbox;
  struct newtExitStruct es;
  int result = 0;
  va_list ap;

  if (p->fname)
    title = concat(atitle, p->fname, NULL);  
  else
    title = concat(atitle, p->name, "-", p->version, "-", p->release, NULL);  
  newtCenteredWindow(qwnd_w, qwnd_h, title);
  newtPushHelpLine("Enter, F12 - Exit");
  form = newtForm(NULL, NULL, 0);
  textbox = newtTextbox(0, 0, qwnd_w+1, qwnd_h, NEWT_TEXTBOX_SCROLL | NEWT_TEXTBOX_WRAP);
  newtFormAddComponent(form, textbox);

  txt = strdup(txt1);
  if (long1 == 3)
    query = concat("rpm ", cmd1, " -p ", p->fname, " 2>&1", NULL);
  else
  if (long1)
    query = concat("rpm ", cmd1, " ", p->name, "-", p->version, "-", p->release, " 2>&1", NULL);
  else
    query = concat("rpm ", cmd1, " ", p->name, " 2>&1", NULL);
  newtTextboxSetText(textbox, txt);
  
  va_start(ap, long1);
  do {
    newtPushHelpLine(query);
    newtRefresh();
    f = popen(query, "r");
    line = NULL; N = 0;
    err = getdelim(&line, &N, EOF, f);
    pclose(f);
  
    if (err < 0 && line)
      free(line);
    else
      {
        if (long1 == 2) caps = strdup(line);
	if (*line == '\0' || line[strlen(line)-1] != '\n')
	  { char * tmp = concat(txt, line, "\n", NULL);
	    free(txt); free(line); txt = tmp;
	  }
	else
          txt = concat_and_free(txt, line);
      }
    newtPopHelpLine();
    free(query);
    
    txt1 = va_arg(ap, const char *);
    if (!txt1) break;
    line = concat(txt, txt1, NULL);
    free(txt); txt = line;
    cmd1 = va_arg(ap, const char *);
    if (!cmd1) break;
    long1 = va_arg(ap, int);
    if (long1 == 3)
      query = concat("rpm ", cmd1, " -p ", p->fname, " 2>&1", NULL);
    else
    if (long1)
      query = concat("rpm ", cmd1, " ", p->name, "-", p->version, "-", p->release, " 2>&1", NULL);
    else
      query = concat("rpm ", cmd1, " ", p->name, " 2>&1", NULL);
    newtTextboxSetText(textbox, txt);
  } while (1);
  va_end(ap);
  
  if (caps && strcmp(caps, "(none)") != 0)
    {
      char * s1, * s2;
      s1 = caps; s2 = caps;
      while (*s1)
        {
          while (*s2 && *s2 != '\n') s2++;
          if (*s2)
            *(s2++) = '\0';
          line = concat(txt, "\nWhich packages require ", s1, ":\n", NULL);
          free(txt); txt = line;
          query = concat("rpm -q --whatrequires ", s1, " 2>&1", NULL);
	  newtTextboxSetText(textbox, txt);
	  newtPushHelpLine(query);
	  newtRefresh();
	  f = popen(query, "r");
	  line = NULL; N = 0;
	  err = getdelim(&line, &N, EOF, f);
	  pclose(f);
  
	  if (err < 0 && line)
            free(line);
	  else
            {
    	      if (long1 == 2) caps = strdup(line);
    	      txt = concat_and_free(txt, line);
            }
	  newtPopHelpLine();
	  free(query);
	  
          s1 = s2;
	}
    }
  if (caps)
    free(caps);
  
  newtTextboxSetText(textbox, txt);
  
  newtFormAddHotKey(form, NEWT_KEY_F1);
  newtFormAddHotKey(form, NEWT_KEY_ENTER);
  /* newt-0.21 text widget crashes on these keys so we trap them */
  newtFormAddHotKey(form, NEWT_KEY_PGUP); 
  newtFormAddHotKey(form, NEWT_KEY_PGDN);
  do {
    newtFormRun(form, &es); 
  } while (es.reason == NEWT_EXIT_HOTKEY 
	   && (es.u.key == NEWT_KEY_PGUP || es.u.key == NEWT_KEY_PGDN));
  newtPopHelpLine();
  newtPopWindow();
  newtFormDestroy(form);
  free(txt);
  free(title);
  return result;
}

enum pkg_cmd { CMD_QUERY, CMD_FILES, CMD_VERIFY, CMD_DEPEND, CMD_UNINSTALL,
	       CMD_INSTALL, CMD_UPGRADE };

void
doCmd(pkg p, enum pkg_cmd cmd)
{
  if (p == NULL)
    {
      allPackages();
      return;
    }
  if (p->line == NULL)
    {
      groupPackages(p);
      return;
    }
  switch (cmd) {
    case CMD_QUERY:
      doQuery(p, "Query: ", "-q -i", 1);
      break;
    case CMD_FILES:
      doQuery(p, "Files: ", "-q -l", 1);
      break;
    case CMD_VERIFY:
      doQuery(p, "Verify: ", "-V", 0);
      break;
    case CMD_DEPEND: 
      if (p->fname)
        doQuery2(p, "Dependencies: ", "Required packages:\n", "-q --requires", 3,
                 "\nProvided capabilities:\n", "-q --provides", 3, NULL);
      else
        {
          char * tmp = concat("\nWhich packages require ", p->name, ":\n", NULL);
          doQuery2(p, "Dependencies: ", "Required packages:\n", "-q --requires", 1,
                   "\nProvided capabilities:\n", "-q --provides", 2,
                   tmp, "-q --whatrequires", 0, NULL);
          free(tmp);
	}
      break;
    case CMD_UNINSTALL:
      if (newtWinChoice("Uninstall", "Yes", "No", 
			    "Are you sure you want to uninstall %s-%s-%s?",
			    p->name, p->version, p->release) == 0) 
	{
          if (doQuery(p, "Uninstall: ", "-e", 0))
	    { /* Success */
	      pkg q = pkgFindOrig(pkgListI, p);
	      pkgFreeList(pkgSubList); pkgSubList = NULL;
	      pkgList = pkgListI = pkgRemove(pkgListI, q);
	      pkgAddToGroup(pkgListI, q->group, -q->size);
	      pkgFree(q);
	      doRefresh();
	    }
        }
      break;
    case CMD_INSTALL:
      if (newtWinChoice("Install", "Yes", "No", 
			    "Are you sure you want to install %s-%s-%s?",
			    p->name, p->version, p->release) == 0) 
	{
          if (doQuery(p, "Install: ", "-i", 0))
	    { /* Success */
	      pkgListI = pkgAddCopy(pkgListI, p);
	      pkgAddToGroup(pkgListI, p->group, p->size);
	    }
        }
      break;
    case CMD_UPGRADE:
      if (newtWinChoice("Upgrade", "Yes", "No", 
			    "Are you sure you want to upgrade %s-%s-%s?",
			    p->name, p->version, p->release) == 0) 
	{
          if (doQuery(p, "Upgrade: ", "-U", 0))
	    { /* Success */
	      pkgListI = pkgAddCopy(pkgListI, p);
	      pkgAddToGroup(pkgListI, p->group, p->size);
	    }
        }
      break;
  }
}

/* View modes */

enum view_mode { VIEW_QUIT, VIEW_INSTALLED, VIEW_AVAILABLE };

/* Installed packages */

char * filenameI = NULL;

enum view_mode
installedPkgs(void)
{
  newtComponent form = NULL;
  newtComponent queryBtn, filesBtn, verifyBtn, depBtn, uninstBtn, exitBtn;
  struct newtExitStruct es;
  int mode;

  if (!pkgListI)
    {
      if (filenameI)
        {
          char * tmp = concat("Reading list of packages from ", filenameI, "...", NULL);
          newtPushHelpLine(tmp); 
          free(tmp);
        }
      else
        newtPushHelpLine("Querying installed packages...");
      newtRefresh();
    
      if (filenameI)
        pkgListI = pkgLoad(filenameI);
      else
        pkgListI = pkgGetInstalled();

      newtPopHelpLine();
    }
  pkgList = pkgListI;
  pkgSubList = NULL;
  lastDir = NULL;
  
  if (filenameI)
    {
      char * tmp = concat("Packages in ", filenameI, NULL);
      newtCenteredWindow(wnd_w, wnd_h, tmp);
      free(tmp);
    }
  else
    newtCenteredWindow(wnd_w, wnd_h, "Installed Packages");
  newtPushHelpLine("F1...F5 - Commands, F11 - Available, F12 - Exit");
  form = newtForm(NULL, NULL, 0);
  label = newtLabel(2, 1, "All packages");
  listbox = newtListbox(2, 2, wnd_h-5, NEWT_LISTBOX_RETURNEXIT);
  newtListboxSetWidth(listbox, wnd_w-4);
  
  allPackages();

  newtFormAddComponent(form, label);
  newtFormAddComponent(form, listbox);
  newtFormAddComponent(form, queryBtn = newtCompactButton(1, wnd_h-2, "Query"));
  newtFormAddComponent(form, filesBtn = newtCompactButton(11, wnd_h-2, "Files"));
  newtFormAddComponent(form, depBtn = newtCompactButton(21, wnd_h-2, "Dependencies"));
  newtFormAddComponent(form, verifyBtn = newtCompactButton(38, wnd_h-2, "Verify"));
  newtFormAddComponent(form, uninstBtn = newtCompactButton(49, wnd_h-2, "Uninstall"));
  newtFormAddComponent(form, exitBtn = newtCompactButton(63, wnd_h-2, "Exit"));
  newtFormAddHotKey(form, NEWT_KEY_F1);
  newtFormAddHotKey(form, NEWT_KEY_F2);
  newtFormAddHotKey(form, NEWT_KEY_F3);
  newtFormAddHotKey(form, NEWT_KEY_F4);
  newtFormAddHotKey(form, NEWT_KEY_F5);
  newtFormAddHotKey(form, NEWT_KEY_F11);
  newtFormAddHotKey(form, NEWT_KEY_F12);
  for(;;) 
    {
      newtFormRun(form, &es);
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F1) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == listbox) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == queryBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_QUERY);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F2) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == filesBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_FILES);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F3) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == depBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_DEPEND);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F4) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == verifyBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_VERIFY);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F5) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == uninstBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_UNINSTALL);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F12) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == exitBtn))
	{
	  mode = VIEW_QUIT;
	  break;
        }
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F11))
	{
	  mode = VIEW_AVAILABLE;
	  break;
        };
    }
  newtPopHelpLine();
  newtPopWindow();
  newtFormDestroy(form);
  return mode;
}

/* Available packages */

#define default_dirA	"/mnt/cdrom/RedHat/RPMS/"
char * dirA = NULL;
char * filenameA = NULL;


void show_info(const char * s)
{
  char * tmp = concat("Scanning: ", s, NULL);
  newtPopHelpLine();
  newtPushHelpLine(tmp);
  newtRefresh();
  free(tmp);
}

enum view_mode
availablePkgs(void)
{
  newtComponent form = NULL;
  newtComponent queryBtn, filesBtn, depBtn, instBtn, upgrBtn, exitBtn;
  struct newtExitStruct es;
  int mode;

  if (!pkgListA)
    {
      if (filenameA)
        {
          char * tmp = concat("Reading list of packages from ", filenameA, "...", NULL);
          newtPushHelpLine(tmp); 
          free(tmp);
        }
      else
        newtPushHelpLine("Scanning available packages...");
      newtRefresh();
    
      if (filenameA)
        pkgListA = pkgLoad(filenameA);
      else
        pkgListA = pkgGetAvailable(dirA, show_info);

      newtPopHelpLine();
    }
  pkgList = pkgListA;
  pkgSubList = NULL;
  lastDir = NULL;
  
  if (filenameA)
    {
      char * tmp = concat("Available Packages in ", filenameA, NULL);
      newtCenteredWindow(wnd_w, wnd_h, tmp);
      free(tmp);
    }
  else
    newtCenteredWindow(wnd_w, wnd_h, "Available Packages");
  newtPushHelpLine("F1...F5 - Commands, F11 - Installed, F12 - Exit");
  form = newtForm(NULL, NULL, 0);
  label = newtLabel(2, 1, "All packages");
  listbox = newtListbox(2, 2, wnd_h-5, NEWT_LISTBOX_RETURNEXIT);
  newtListboxSetWidth(listbox, wnd_w-4);
  
  allPackages();

  newtFormAddComponent(form, label);
  newtFormAddComponent(form, listbox);
  newtFormAddComponent(form, queryBtn = newtCompactButton(1, wnd_h-2, "Query"));
  newtFormAddComponent(form, filesBtn = newtCompactButton(11, wnd_h-2, "Files"));
  newtFormAddComponent(form, depBtn = newtCompactButton(21, wnd_h-2, "Dependencies"));
  newtFormAddComponent(form, instBtn = newtCompactButton(38, wnd_h-2, "Install"));
  newtFormAddComponent(form, upgrBtn = newtCompactButton(50, wnd_h-2, "Upgrade"));
  newtFormAddComponent(form, exitBtn = newtCompactButton(62, wnd_h-2, "Exit"));
  newtFormAddHotKey(form, NEWT_KEY_F1);
  newtFormAddHotKey(form, NEWT_KEY_F2);
  newtFormAddHotKey(form, NEWT_KEY_F3);
  newtFormAddHotKey(form, NEWT_KEY_F4);
  newtFormAddHotKey(form, NEWT_KEY_F5);
  newtFormAddHotKey(form, NEWT_KEY_F11);
  newtFormAddHotKey(form, NEWT_KEY_F12);
  for(;;) 
    {
      newtFormRun(form, &es);
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F1) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == listbox) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == queryBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_QUERY);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F2) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == filesBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_FILES);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F3) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == depBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_DEPEND);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F4) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == instBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_INSTALL);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F5) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == upgrBtn))
        doCmd(newtListboxGetCurrent(listbox), CMD_UPGRADE);
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F12) ||
          (es.reason == NEWT_EXIT_COMPONENT && es.u.co == exitBtn))
	{
	  mode = VIEW_QUIT;
	  break;
        }
      else
      if ((es.reason == NEWT_EXIT_HOTKEY && es.u.key == NEWT_KEY_F11))
	{
	  mode = VIEW_INSTALLED;
	  break;
        };
    }
  newtPopHelpLine();
  newtPopWindow();
  newtFormDestroy(form);
  return mode;
}

/* Main, at last */ 

int
main(int argc, char ** argv)
{
  int cols, rows;
  static struct option long_options[] = {
    {"version",		no_argument,		NULL,	'V'},
    {"help",		no_argument,		NULL,	'h'},
    {"load",		required_argument,	NULL,	'l'},
    {"load-available",	required_argument,	NULL,	'L'},
    {"from",		required_argument,	NULL,	'f'},
    {"available",	no_argument,		NULL,	'a'},
    {0, 0, 0, 0}
  };
  int opt;
  int tmp = 0;
  int mode = VIEW_INSTALLED;

  /* Process command-line options */
  while ((opt = getopt_long(argc, argv, "Vhal:L:f:", long_options, &tmp)) != -1)
    {
      switch (opt)
        {
        case 'V': /* -V, --version */
          printf("Text Linux Installation Tool version " VERSION "\n"
                 "Copyright (c) 1998, Marius Gedminas <mgedmin@pub.osf.lt>\n");
          exit(EXIT_SUCCESS);
        case 'h': /* -h, --help */
          printf("Usage: %s [-a] [-h] [-v] [-l file] [-L file] [-f path] [--help] [--version]\n"
	         "	 [--available] [--load file] [--load-available file] [--from path]\n\n"
		 "  -a, --available        show Available Packages initially\n"
                 "  -l, --load             read list of packages from file\n"
		 "                         each line describes one package in this format:\n"
		 "                         :group:name:version:release:size (bytes):summary\n"
                 "  -L, --load-available   read list of available packages from file\n"
		 "                         each line describes one package in this format:\n"
		 "                         /path/filename:group:name:version:release:size:summary\n"
                 "  -f, --from             specify path for available packages\n"
		 "                         (default: /mnt/cdrom/RedHat/RPMS/)\n"
		 "                         --load-available takes precedence over --from\n"
                 "  -h, --help             display this help and exit\n"
                 "  -V, --version          display version information and exit\n",
                 argv[0]);
          exit(EXIT_SUCCESS);
	case 'a': /* -a, --available */ 
	  mode = VIEW_AVAILABLE;
	  break;
	case 'l': /* -l, --load */ 
	  if (filenameI) free(filenameI);
	  filenameI = strdup(optarg);
          break;
	case 'L': /* -L, --load-available */ 
	  if (filenameA) free(filenameA);
	  filenameA = strdup(optarg);
          break;
	case 'f': /* -f, --from */ 
	  if (dirA) free(dirA);
	  dirA = strdup(optarg);
          break;
	}
    }
  if (!dirA) dirA = default_dirA;
  newtInit();
  newtCls();
  newtGetScreenSize(&cols, &rows);
  wnd_w = cols-2; wnd_h = rows-5;
  qwnd_w = cols-2; qwnd_h = rows-5;
  newtDrawRootText(0, 0, "Text Linux Installation Tool");
  newtDrawRootText(0, cols-strlen(VERSION), VERSION);
  newtPushHelpLine(NULL);
  
  while (mode != VIEW_QUIT) 
    switch (mode) {
      case VIEW_INSTALLED:
        mode = installedPkgs();
	break;
      case VIEW_AVAILABLE:
        mode = availablePkgs();
	break;
      default:
        mode = VIEW_QUIT;
    }
  
  newtFinished();
  exit(EXIT_SUCCESS);
}

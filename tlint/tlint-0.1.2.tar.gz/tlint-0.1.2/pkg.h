/*
 * Copyright (c) 1998 Marius Gedminas <mgedmin@pub.osf.lt>
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write to the Free Software
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
#ifndef _PKG_H
#define _PKG_H

struct pkg_s {
  char * line;
  int orig_line_len;
  char * fname;
  char * name;
  char * version;
  char * release;
  char * group;
  long size;
  char * summary;
  struct pkg_s * next;
};
typedef struct pkg_s * pkg;

/* Special `group' pkgs:
 *   line == NULL
 *   name == current group name
 *   version, release == NULL 
 *   group == parent group
 *   size == sum of packages in group
 *   summary == full group name
 *
 * e.g. entry for <Applications/Editors/EMACS> would look like
 *   name = "EMACS"
 *   group = "Applications/Editors"
 *   summary = "Applications/Editors/EMACS"
 */

pkg pkgLoad(const char * fname);
pkg pkgGetInstalled(void);
pkg pkgGetAvailable(const char * path, void (*info)(const char * s));
void pkgFree(pkg p);

pkg pkgFindGroup(pkg list, const char * group);

pkg pkgCopyList(pkg p);
pkg pkgExtractList(pkg p, const char * group);
pkg pkgSortList(pkg p);
void pkgFreeList(pkg p);
pkg pkgRemove(pkg list, pkg p);
pkg pkgAddCopy(pkg list, pkg p);

void pkgAddToGroup(pkg list, const char * group, int delta);

pkg pkgFindOrig(pkg list, pkg p);

/* Format text in the form  "<name>  <summary>           <size>" */
void pkgText(pkg p, char * buf, int width, int width1, int width2);

/* Format text in the form  "<custom-text>               <size>" */
void pkgCustomText(pkg p, char * buf, const char * txt, int width, int widths12);

#endif
/*
 * Copyright (c) 1998 Marius Gedminas <mgedmin@pub.osf.lt>
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program; if not, write to the Free Software
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define _GNU_SOURCE	/* glibc2 required for getline */ 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <glob.h>

#include "pkg.h"
#include "util.h"

pkg pkgFindGroup(pkg list, const char * group)
{
  pkg p = list;
  while (p && !p->line && strcmp(p->summary, group) != 0)
    p = p->next;
  if (p && p->line) 
    p = NULL;
  return p;
}

static pkg findgroup(pkg * list, const char * group)
{
  pkg p = pkgFindGroup(*list, group);
  if (!p || p->line)
    {
      int i;
      p = (pkg)malloc(sizeof(*p));
      p->line = NULL;
      p->fname = NULL;
      p->version = NULL;
      p->release = NULL;
      p->size = 0;
      p->summary = strdup(group);

      i = strlen(p->summary);
      while (i > 0 && p->summary[i] != '/') i--;
      if (i == 0)
        { 
	  p->name = strdup(p->summary);
	  if (*p->summary == '\0')
  	    p->group = strdup(":"); /* so that no-one matches it */
	  else
  	    p->group = strdup("");
	}
      else
        {
	  p->name = strdup(&p->summary[i+1]);
	  p->summary[i] = '\0';
	  p->group = strdup(p->summary);
	  p->summary[i] = '/';
	}

      p->next = *list;
      *list = p;
    }
  return p;
}

pkg pkgCalcGroups(pkg list)
/* list must not contain groups */
{
  pkg p = list, g;
  int i;
  while (p)
    {
      g = findgroup(&list, p->group);
      g->size += p->size;
      i = strlen(p->group);
      while (i > 0 && p->group[i] != '/') i--;
      while (i > 0)
        {
	  p->group[i] = '\0';
	  g = findgroup(&list, p->group);
          g->size += p->size;
	  p->group[i] = '/';
	  i--;
          while (i > 0 && p->group[i] != '/') i--;
	}
      if (*p->group != '\0')
        {
	  g = findgroup(&list, "");
          g->size += p->size;
	}
      p = p->next;
    }
  return list;
}

pkg pkgDoLoad(FILE * f, pkg list)
{
  char * line, * tmp;
  size_t N;
  pkg p = list, t;
  
  for (;;) 
    {    
      line = NULL; N = 0;
      if (getline(&line, &N, f) < 0)
        break;
      /* group:name:ver:rel:size:summary */
      t = (pkg) malloc(sizeof(*t));
      t->line = line;
      t->orig_line_len = strlen(line);
      t->fname = line;
      while (*line && *line != ':') line++; if (*line) *(line++) = '\0';
      if (*t->fname == '\0') t->fname = NULL;
      t->group = line;
      while (*line && *line != ':') line++; if (*line) *(line++) = '\0';
      t->name = line;
      while (*line && *line != ':') line++; if (*line) *(line++) = '\0';
      t->version = line;
      while (*line && *line != ':') line++; if (*line) *(line++) = '\0';
      t->release = line;
      while (*line && *line != ':') line++; if (*line) *(line++) = '\0';
      tmp = line;
      while (*line && *line != ':') line++; if (*line) *(line++) = '\0';
      t->size = strtol(tmp, NULL, 0);
      t->summary = line;
      while (*line && *line != '\n') line++; if (*line) *(line++) = '\0';
      t->next = p; p = t;
    }
  
  return p;
}

pkg pkgLoad(const char * fname)
{
  FILE * f;
  pkg p;
  
  f = fopen(fname, "r");
  if (!f)
    return NULL;

  p = pkgDoLoad(f, NULL);
  p = pkgCalcGroups(p);
  p = pkgSortList(p);
  
  fclose(f);
  return p;
}

pkg pkgGetInstalled(void)
{
  FILE * f;
  pkg p;
  
  f = popen("rpm -q -a --queryformat ':%{GROUP}:%{NAME}:%{VERSION}:%{RELEASE}:%{SIZE}:%{SUMMARY}\n'", "r");
  if (!f)
    return NULL;

  p = pkgDoLoad(f, NULL);
  p = pkgCalcGroups(p);
  p = pkgSortList(p);
  
  pclose(f);
  return p;
}

pkg pkgGetAvailable(const char * path, void (*info)(const char *s))
{
  glob_t data;
  char * pattern = concat(path, "/*.rpm", NULL);
  int result;
  int i;
  FILE * f;
  pkg p = NULL;
  
  if (info)
    (*info)(pattern);
  result = glob(pattern, 0, NULL, &data);
  free(pattern);
  
  for(i = 0; i < data.gl_pathc; i++)
    {
      if (info)
        (*info)(data.gl_pathv[i]);
      pattern = concat("rpm -q --queryformat '",
                       data.gl_pathv[i],
                       ":%{GROUP}:%{NAME}:%{VERSION}:%{RELEASE}:%{SIZE}:%{SUMMARY}\n' -p ",
                       data.gl_pathv[i], NULL);
      f = popen(pattern, "r");
      free(pattern);
      if (!f)
        continue;

      p = pkgDoLoad(f, p);
  
      pclose(f);
    }
  if (info)
    (*info)("");
  free(data.gl_pathv);
  p = pkgCalcGroups(p);
  p = pkgSortList(p);
  return p;
}

void pkgFree(pkg p)
{
  pkg n;
  while (p)
    {
      n = p->next;
      if (p->line)
        free(p->line);
      else
        {
	  free(p->name);
	  free(p->group);
	  free(p->summary);
	}
      free(p);
      p = n;
    }
}

pkg pkgCopyList(pkg p)
{
  pkg l;
  if (!p)
    return NULL;
  l = (pkg)malloc(sizeof(*l));
  *l = *p;
  l->next = pkgCopyList(p->next);
  return l;
}

pkg pkgExtractList(pkg p, const char * group)
{
  pkg l;
  while (p && strcmp(p->group, group) != 0)
    p = p->next;
  if (!p)
    return NULL;
  l = (pkg)malloc(sizeof(*l));
  *l = *p;
  l->next = pkgExtractList(p->next, group);
  return l;
}

int pkgCompare(pkg p1, pkg p2)
{
  if (p1->line == NULL && p2-> line != NULL)
    return -1; /* p1 is a group */
  else if (p1->line != NULL && p2-> line == NULL)
    return 1; /* p2 is a group */
  else
    return strcmp(p1->name, p2->name);
}

static pkg split(pkg p)
{
  pkg second;
  if (!p || !p->next)
    return NULL;
  second = p->next;
  p->next = second->next;
  second->next = split(second->next);
  return second;
}

static pkg merge(pkg p1, pkg p2)
{
  if (!p1)
    return p2;
  if (!p2)
    return p1;
  if (pkgCompare(p1, p2) <= 0)
    {
      p1->next = merge(p1->next, p2);
      return p1;
    }
  else
    {
      p2->next = merge(p2->next, p1);
      return p2;
    }
}

pkg pkgSortList(pkg p)
{
  pkg second;
  if (!p || !p->next)
    return p;
  second = pkgSortList(split(p));
  return merge(pkgSortList(p), second);
}

void pkgFreeList(pkg p)
{
  pkg n;
  while (p)
    {
      n = p->next;
      free(p);
      p = n;
    }
}

pkg pkgRemove(pkg list, pkg p)
{
  pkg tmp;

  if (!p)
    return list;
  if (!list)
    {
      p->next = NULL;
      return list;
    }

  if (p == list)
    {
      tmp = list->next;
      p->next = NULL;
      return tmp;
    }
  else
    {
      tmp = list;
      while (tmp->next && tmp->next != p)
        tmp = tmp->next;
      if (!tmp->next)
        {
          p->next = NULL;
          return list;
	}
      tmp->next = p->next;
      p->next = NULL;
      return list;
    }
}

pkg pkgInsert(pkg list, pkg p)
{
  pkg tmp;
  if (pkgCompare(p, list) <= 0)
    {
      p->next = list;
      list = p;
      return list;
    }
  tmp = list;
  while (tmp->next && pkgCompare(p, tmp->next) > 0)
    tmp = tmp->next;
  p->next = tmp->next;
  tmp->next = p;
  return list;
}

pkg pkgAddCopy(pkg list, pkg p)
{
  pkg l;
  l = (pkg)malloc(sizeof(*l));
  l->line = (char *)malloc(p->orig_line_len+1);
  memcpy(l->line, p->line, p->orig_line_len+1);
  l->orig_line_len = p->orig_line_len;
  l->fname = NULL;
  l->group = l->line + (p->group - p->line);
  l->name = l->line + (p->name - p->line);
  l->version = l->line + (p->version - p->line);
  l->release = l->line + (p->release - p->line);
  l->size = p->size;
  l->summary = l->line + (p->summary - p->line);
  l->next = NULL;
  return pkgInsert(list, l);
}

/* Silly name... should have been called isParent or something */
static int isSubgroup(const char * subgroup, const char * group)
{
  int n = strlen(subgroup);
  if (n == 0)
    return 1; /* "" is the ultimate subgroup */
  if (strncmp(subgroup, group, n) != 0)
    return 0; /* strings differ */
  return (group[n] == '\0' || group[n] == '/');
}

void pkgAddToGroup(pkg list, const char * group, int delta)
{
  pkg p = list;
  while (p)
    {
      if (!p->line && isSubgroup(p->summary, group))
        p->size += delta;
      p = p->next;
    }
}

pkg pkgFindOrig(pkg list, pkg p)
{
  pkg q = list;
  while (q && q->line != p->line)
    q = q->next;
  return q;
}

void pkgText(pkg p, char * buf, int width, int width1, int width2)
{
  int n;
  /*  (name-ver-rel:width1 summary:width2  size):width */
  snprintf(buf, width+1, "%*ld", width, p->size/1024);
  if (p->line == NULL)
    {
      n = snprintf(buf, width1+width2, "<%s>", p->name); 
      if (n <= 0) n = width1+width2-1; 
      buf[n] = ' ';
    }
  else
    {
      n = snprintf(buf, width1, "%s-%s-%s", p->name, p->version, p->release); 
      if (n <= 0) n = width1-1; 
      buf[n] = ' ';
      n = snprintf(&buf[width1], width2, "%s", p->summary); 
      if (n <= 0) n = width2-1; 
      buf[width1+n] = ' ';
    }
}

void pkgCustomText(pkg p, char * buf, const char * txt, int width, int widths12)
{
  int n;
  snprintf(buf, width+1, "%*ld", width, p->size/1024);
  n = snprintf(buf, widths12, "%s", txt); 
  if (n <= 0) n = widths12-1; 
  buf[n] = ' ';
}
